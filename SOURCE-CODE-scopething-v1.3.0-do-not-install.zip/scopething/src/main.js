// ScopeThing client - runs on the Car Thing.
// Plain JavaScript on purpose (same approach as Flex Thing): small, fast, and
// it uses the minimal DeskThing iframe bridge that is proven on the device.

(function () {
  'use strict';

  // ==========================================================
  // DESKTHING BRIDGE
  // ==========================================================
  var listeners = {};
  function on(type, cb) { (listeners[type] = listeners[type] || []).push(cb); }
  function emit(type, data) {
    var l = listeners[type];
    if (!l) return;
    for (var i = 0; i < l.length; i++) {
      try { l[i](data); } catch (e) { console.error('[ScopeThing] listener error', type, e); }
    }
  }
  function send(type, payload) {
    try {
      window.parent.postMessage({ type: 'IFRAME_ACTION', payload: { app: void 0, type: type, request: null, payload: payload === undefined ? null : payload } }, '*');
    } catch (e) { console.error('[ScopeThing] send error', e); }
  }
  window.addEventListener('message', function (event) {
    var d = event.data;
    if (d && d.source === 'deskthing') emit(d.type, d);
  });

  // ==========================================================
  // STATE
  // ==========================================================
  var W = 800, H = 388, TILE = 256;
  var ambient = false;
  var lastInteract = Date.now();
  var cfg = null;
  var view = { lat: 41.8781, lon: -87.6298, z: 9 };
  var homeView = null;
  var nodes = [];
  var mineKeys = {};
  var mineCards = [];
  var pendingMine = {};
  var feed = [];
  var anims = [];
  var pulses = [];
  var tiles = {};
  var tilePending = {};
  var paused = false;
  var screen = 'map';
  var lastStatus = { conn: 'starting', msg: '', ppm: 0, nodes: 0 };
  var selected = null;
  var baseDirty = true;
  var fxRunning = false;

  var $ = function (id) { return document.getElementById(id); };
  var baseCanvas = $('baseCanvas'), fxCanvas = $('fxCanvas');
  var bctx = baseCanvas.getContext('2d'), fctx = fxCanvas.getContext('2d');

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function ago(ts) {
    if (!ts) return 'never';
    var s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return s + 's';
    if (s < 3600) return Math.floor(s / 60) + 'm';
    if (s < 86400) return Math.floor(s / 3600) + 'h';
    return Math.floor(s / 86400) + 'd';
  }
  function fmtSnr(v) { return v == null ? '-' : (v > 0 ? '+' : '') + (Math.round(v * 100) / 100); }

  // ==========================================================
  // PROJECTION (Web Mercator)
  // ==========================================================
  function worldXY(lat, lon, z) {
    var s = TILE * Math.pow(2, z);
    var sin = Math.sin(lat * Math.PI / 180);
    sin = Math.min(Math.max(sin, -0.9999), 0.9999);
    return [(lon + 180) / 360 * s, (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s];
  }
  function unproject(x, y, z) {
    var s = TILE * Math.pow(2, z);
    var lon = x / s * 360 - 180;
    var n = Math.PI - 2 * Math.PI * y / s;
    return [180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lon];
  }
  var centerW = [0, 0];
  function updateCenterW() { centerW = worldXY(view.lat, view.lon, view.z); }
  function toScreen(lat, lon) {
    var w = worldXY(lat, lon, view.z);
    return [w[0] - centerW[0] + W / 2, w[1] - centerW[1] + H / 2];
  }
  function metersPerPixel(lat, z) { return 156543.03392 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z); }
  function fitZoom(lat, radiusMi) {
    for (var z = 15; z >= 4; z--) {
      if (radiusMi * 1609.34 / metersPerPixel(lat, z) <= 175) return z;
    }
    return 4;
  }

  // ==========================================================
  // BASE LAYER: tiles, radius ring, nodes
  // ==========================================================
  function markBase() { baseDirty = true; kick(); }

  function neededTiles() {
    var z = view.z, n = Math.pow(2, z);
    var x0 = Math.floor((centerW[0] - W / 2) / TILE), x1 = Math.floor((centerW[0] + W / 2) / TILE);
    var y0 = Math.max(0, Math.floor((centerW[1] - H / 2) / TILE)), y1 = Math.min(n - 1, Math.floor((centerW[1] + H / 2) / TILE));
    var out = [];
    for (var x = x0; x <= x1; x++) for (var y = y0; y <= y1; y++) out.push({ z: z, x: ((x % n) + n) % n, y: y, dx: x });
    return out;
  }

  function requestTiles() {
    if (!cfg || cfg.mapStyle.indexOf('none') === 0) return;
    var need = neededTiles(), ask = [];
    for (var i = 0; i < need.length; i++) {
      var t = need[i], key = cfg.mapStyle + '/' + t.z + '/' + t.x + '/' + t.y;
      if (!tiles[key] && !tilePending[key]) { tilePending[key] = Date.now(); ask.push({ z: t.z, x: t.x, y: t.y }); }
    }
    if (ask.length) send('getTiles', { tiles: ask });
  }

  function drawBase() {
    baseDirty = false;
    bctx.fillStyle = '#0A0E13';
    bctx.fillRect(0, 0, W, H);
    var style = cfg ? cfg.mapStyle : 'none';
    var drewTile = false;
    if (style.indexOf('none') !== 0) {
      var need = neededTiles();
      for (var i = 0; i < need.length; i++) {
        var t = need[i], img = tiles[style + '/' + t.z + '/' + t.x + '/' + t.y];
        if (img) {
          bctx.drawImage(img, Math.round(t.dx * TILE - centerW[0] + W / 2), Math.round(t.y * TILE - centerW[1] + H / 2), TILE, TILE);
          drewTile = true;
        }
      }
    }
    if (!drewTile) {
      bctx.strokeStyle = '#111923';
      bctx.lineWidth = 1;
      var ox = (-centerW[0] + W / 2) % 40, oy = (-centerW[1] + H / 2) % 40;
      bctx.beginPath();
      for (var gx = ox; gx < W; gx += 40) { bctx.moveTo(gx, 0); bctx.lineTo(gx, H); }
      for (var gy = oy; gy < H; gy += 40) { bctx.moveTo(0, gy); bctx.lineTo(W, gy); }
      bctx.stroke();
    }
    if (style.indexOf('light') === 0) { bctx.fillStyle = 'rgba(10,14,19,0.35)'; bctx.fillRect(0, 0, W, H); }

    // Watch radius
    if (cfg && cfg.center) {
      var c = toScreen(cfg.center[0], cfg.center[1]);
      var r = cfg.radiusMi * 1609.34 / metersPerPixel(cfg.center[0], view.z);
      bctx.save();
      bctx.setLineDash([4, 6]);
      bctx.strokeStyle = 'rgba(57,208,255,0.35)';
      bctx.lineWidth = 1.5;
      bctx.beginPath(); bctx.arc(c[0], c[1], r, 0, Math.PI * 2); bctx.stroke();
      bctx.restore();
    }

    // Nodes: companions first, then repeaters, then mine on top
    var labels = [];
    var order = [0, 1, 2];
    for (var pass = 0; pass < order.length; pass++) {
      for (var j = 0; j < nodes.length; j++) {
        var nd = nodes[j];
        var isMine = !!mineKeys[nd.k], isRpt = nd.r === 'repeater';
        var layer = isMine || nd.w ? 2 : isRpt ? 1 : 0;
        if (layer !== pass) continue;
        var p = toScreen(nd.la, nd.lo);
        nd.sx = p[0]; nd.sy = p[1];
        if (p[0] < -20 || p[0] > W + 20 || p[1] < -20 || p[1] > H + 20) continue;
        drawNode(bctx, nd, p, isMine);
        if (isMine || nd.w || (isRpt && view.z >= 11)) labels.push([nd, p, isMine || nd.w]);
      }
    }
    bctx.font = '10px "Roboto Mono", Consolas, monospace';
    for (var k = 0; k < labels.length; k++) {
      var L = labels[k];
      bctx.fillStyle = 'rgba(10,14,19,0.75)';
      var tw = bctx.measureText(L[0].n).width;
      bctx.fillRect(L[1][0] + 8, L[1][1] - 7, tw + 6, 13);
      bctx.fillStyle = L[2] ? '#FFFFFF' : '#C3CFDB';
      bctx.fillText(L[0].n, L[1][0] + 11, L[1][1] + 3);
    }
    $('stOnMap').textContent = String(nodes.length);
  }

  function roleColor(r) {
    if (r === 'repeater') return '#FFB547';
    if (r === 'room' || r === 'room_server' || r === 'roomserver') return '#B78CFF';
    if (r === 'sensor') return '#3DDC97';
    return '#39D0FF';
  }

  function drawNode(ctx, nd, p, isMine) {
    var col = roleColor(nd.r);
    ctx.fillStyle = col;
    if (nd.r === 'repeater') {
      ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(Math.PI / 4);
      var s = nd.w ? 9 : 7; ctx.fillRect(-s / 2, -s / 2, s, s); ctx.restore();
    } else if (col === '#B78CFF') {
      ctx.fillRect(p[0] - 3.5, p[1] - 3.5, 7, 7);
    } else {
      ctx.beginPath(); ctx.arc(p[0], p[1], 3.2, 0, Math.PI * 2); ctx.fill();
    }
    if (isMine || nd.w) {
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(p[0], p[1], 8, 0, Math.PI * 2); ctx.stroke();
    }
  }

  // ==========================================================
  // FX LAYER: streaks + pulses
  // ==========================================================
  function hexToRgb(h) {
    var n = parseInt(h.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgba(rgb, a) { return 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + a + ')'; }

  function addRoute(r) {
    var rgb = hexToRgb(r.c || '#39D0FF');
    var segs = Math.max(1, r.p.length - 1);
    if (r.p.length >= 2) {
      anims.push({ p: r.p, rgb: rgb, t0: Date.now(), dur: Math.min(4200, 650 + segs * 520), mine: r.mine, pulsed: false });
      if (anims.length > 36) anims.splice(0, anims.length - 36);
    } else {
      pulses.push({ ll: r.p[0], rgb: rgb, t0: Date.now() });
    }
    pulses.push({ ll: r.p[0], rgb: rgb, t0: Date.now(), small: true });
    if (pulses.length > 40) pulses.splice(0, pulses.length - 40);
    kick();
  }

  function pointAt(pts, cum, d) {
    for (var i = 1; i < pts.length; i++) {
      if (cum[i] >= d) {
        var seg = cum[i] - cum[i - 1] || 1, f = (d - cum[i - 1]) / seg;
        return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * f, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * f];
      }
    }
    return pts[pts.length - 1];
  }

  function strokeRange(ctx, pts, cum, a, b) {
    if (b <= a) return;
    var start = pointAt(pts, cum, a);
    ctx.beginPath(); ctx.moveTo(start[0], start[1]);
    for (var i = 1; i < pts.length; i++) {
      if (cum[i] > a && cum[i] < b) ctx.lineTo(pts[i][0], pts[i][1]);
    }
    var end = pointAt(pts, cum, b);
    ctx.lineTo(end[0], end[1]);
    ctx.stroke();
  }

  function drawFx(now) {
    fctx.clearRect(0, 0, W, H);
    fctx.lineCap = 'round'; fctx.lineJoin = 'round';
    var keep = [];
    for (var i = 0; i < anims.length; i++) {
      var a = anims[i];
      var pts = [], cum = [0];
      for (var j = 0; j < a.p.length; j++) pts.push(toScreen(a.p[j][0], a.p[j][1]));
      for (var k = 1; k < pts.length; k++) {
        var dx = pts[k][0] - pts[k - 1][0], dy = pts[k][1] - pts[k - 1][1];
        cum.push(cum[k - 1] + Math.sqrt(dx * dx + dy * dy));
      }
      var L = cum[cum.length - 1];
      var prog = (now - a.t0) / a.dur;
      var fade = prog <= 1 ? 1 : Math.max(0, 1 - (prog - 1) * a.dur / 1600);
      if (fade <= 0) continue;
      keep.push(a);
      var head = Math.min(1, prog) * L;
      // faint trail behind the comet
      fctx.strokeStyle = rgba(a.rgb, 0.28 * fade); fctx.lineWidth = a.mine ? 2.5 : 1.6;
      strokeRange(fctx, pts, cum, 0, head);
      if (prog <= 1.15) {
        var tail = Math.max(0, head - 70);
        fctx.strokeStyle = rgba(a.rgb, 0.22); fctx.lineWidth = 8;
        strokeRange(fctx, pts, cum, tail, head);
        fctx.strokeStyle = rgba(a.rgb, 1); fctx.lineWidth = 2.6;
        strokeRange(fctx, pts, cum, tail, head);
        var hp = pointAt(pts, cum, head);
        fctx.fillStyle = 'rgba(255,255,255,0.95)';
        fctx.beginPath(); fctx.arc(hp[0], hp[1], 2.6, 0, Math.PI * 2); fctx.fill();
      }
      if (prog >= 1 && !a.pulsed) {
        a.pulsed = true;
        pulses.push({ ll: a.p[a.p.length - 1], rgb: a.rgb, t0: now });
      }
    }
    anims = keep;
    var keepP = [];
    for (var m = 0; m < pulses.length; m++) {
      var pu = pulses[m], age = (now - pu.t0) / (pu.small ? 700 : 1100);
      if (age >= 1) continue;
      keepP.push(pu);
      var sp = toScreen(pu.ll[0], pu.ll[1]);
      fctx.strokeStyle = rgba(pu.rgb, (1 - age) * 0.9); fctx.lineWidth = 2;
      fctx.beginPath(); fctx.arc(sp[0], sp[1], (pu.small ? 4 : 5) + age * (pu.small ? 10 : 20), 0, Math.PI * 2); fctx.stroke();
    }
    pulses = keepP;
  }

  var lastFrame = 0;
  function frame(now) {
    now = Date.now();
    if (screen === 'map') {
      if (baseDirty) drawBase();
      if (now - lastFrame >= 30) { drawFx(now); lastFrame = now; }
    }
    if ((anims.length || pulses.length || baseDirty) && screen === 'map') {
      requestAnimationFrame(frame);
    } else {
      fxRunning = false;
      if (screen === 'map') fctx.clearRect(0, 0, W, H);
    }
  }
  function kick() {
    if (!fxRunning && screen === 'map') { fxRunning = true; requestAnimationFrame(frame); }
  }

  // ==========================================================
  // VIEW CONTROL
  // ==========================================================
  function setView(lat, lon, z) {
    view.lat = Math.max(-84, Math.min(84, lat));
    view.lon = ((lon + 540) % 360) - 180;
    view.z = Math.max(3, Math.min(16, z));
    updateCenterW();
    requestTiles();
    markBase();
  }
  function zoom(delta) { setView(view.lat, view.lon, view.z + delta); }
  function recenter() { if (homeView) setView(homeView.lat, homeView.lon, homeView.z); }

  // Touch / mouse: drag to pan, tap to select a node
  var drag = null;
  function ptFromEvent(e) {
    var t = e.touches && e.touches.length ? e.touches[0] : e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e;
    var rect = fxCanvas.getBoundingClientRect();
    return [t.clientX - rect.left, t.clientY - rect.top];
  }
  function down(e) { drag = { start: ptFromEvent(e), last: ptFromEvent(e), moved: false }; }
  function move(e) {
    if (!drag) return;
    var p = ptFromEvent(e);
    var dx = p[0] - drag.last[0], dy = p[1] - drag.last[1];
    if (Math.abs(p[0] - drag.start[0]) + Math.abs(p[1] - drag.start[1]) > 8) drag.moved = true;
    if (drag.moved) {
      var ll = unproject(centerW[0] - dx, centerW[1] - dy, view.z);
      view.lat = ll[0]; view.lon = ll[1]; updateCenterW(); markBase();
    }
    drag.last = p;
    if (e.cancelable) e.preventDefault();
  }
  function up(e) {
    if (!drag) return;
    var wasTap = !drag.moved, p = drag.last;
    drag = null;
    if (wasTap) tapAt(p); else requestTiles();
  }
  fxCanvas.addEventListener('touchstart', down, { passive: true });
  fxCanvas.addEventListener('touchmove', move, { passive: false });
  fxCanvas.addEventListener('touchend', up);
  fxCanvas.addEventListener('mousedown', down);
  window.addEventListener('mousemove', move);
  window.addEventListener('mouseup', up);

  function tapAt(p) {
    if (ambient) { exitAmbient(); return; }
    var best = null, bd = 22 * 22;
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.sx == null) continue;
      var dx = n.sx - p[0], dy = n.sy - p[1], d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = n; }
    }
    if (best) showNodeCard(best); else hideNodeCard();
  }

  function showNodeCard(n) {
    selected = n;
    $('ncRole').textContent = (n.r || 'node').toUpperCase() + (n.w ? '  ·  WATCHED' : '');
    $('ncName').textContent = n.n;
    $('ncMeta').innerHTML = esc(n.k.slice(0, 12)) + '…<br>' + n.la.toFixed(4) + ', ' + n.lo.toFixed(4);
    updateStarBtn();
    $('nodeCard').classList.remove('hidden');
  }
  function hideNodeCard() { selected = null; $('nodeCard').classList.add('hidden'); }
  var watched = []; // [{k, n, src}]
  function isWatched(k, n) {
    for (var i = 0; i < watched.length; i++) {
      if ((k && watched[i].k === k) || (n && watched[i].n.toLowerCase() === String(n).toLowerCase())) return watched[i];
    }
    return null;
  }
  function updateWatchBtn() {
    if (!selected) return;
    var w = isWatched(selected.k, selected.n), b = $('ncWatch');
    b.textContent = w ? (w.src === 'picked' ? '@ Watching mentions (stop)' : '@ Watching (' + (w.src === 'mynode' ? 'My Node' : 'settings') + ')') : '@ Watch mentions';
    b.className = 'btn at' + (w ? ' on' : '');
  }
  $('ncWatch').addEventListener('click', function () {
    if (!selected) return;
    var w = isWatched(selected.k, selected.n);
    if (w && w.src !== 'picked') return; // comes from My Nodes or settings
    send('setMention', { k: selected.k, n: selected.n, on: !w });
  });
  function updateStarBtn() {
    updateWatchBtn();
    if (!selected) return;
    var isMine = !!mineKeys[selected.k], b = $('ncStar');
    b.textContent = isMine ? '★ In My Nodes (remove)' : '★ Add to My Nodes';
    b.className = 'btn star' + (isMine ? ' on' : '');
  }
  $('ncStar').addEventListener('click', function () {
    if (!selected) return;
    var k = selected.k;
    var turnOn = !mineKeys[k];
    if (turnOn) mineKeys[k] = 1; else delete mineKeys[k];
    pendingMine[k] = { on: turnOn, until: Date.now() + 15000 };
    updateStarBtn(); markBase();
    send('toggleMyNode', { k: k, n: selected.n, on: turnOn });
  });
  $('ncClose').addEventListener('click', hideNodeCard);

  $('btnZoomIn').addEventListener('click', function () { zoom(1); });
  $('btnZoomOut').addEventListener('click', function () { zoom(-1); });
  $('btnCenter').addEventListener('click', recenter);
  $('btnPause').addEventListener('click', togglePause);
  function togglePause() {
    paused = !paused;
    $('pausedBadge').classList.toggle('hidden', !paused);
    $('btnPause').textContent = paused ? '▶' : 'II';
  }

  // ==========================================================
  // SCREENS
  // ==========================================================
  var SCREENS = ['map', 'feed', 'chan', 'mine', 'status'];
  function showScreen(name) {
    if (SCREENS.indexOf(name) < 0) return;
    $('alertsPanel').classList.add('hidden');
    $('findPanel').classList.add('hidden');
    screen = name;
    var secs = document.querySelectorAll('.screen');
    for (var i = 0; i < secs.length; i++) secs[i].classList.toggle('active', secs[i].id === 'screen-' + name);
    var tabs = document.querySelectorAll('.tab');
    for (var j = 0; j < tabs.length; j++) tabs[j].classList.toggle('active', tabs[j].getAttribute('data-screen') === name);
    if (name === 'map') { markBase(); requestTiles(); }
    if (name === 'feed') renderFeed();
    if (name === 'mine') renderMine();
    if (name === 'chan') { unreadTotal = 0; updateBadge(); if (!channels.length) send('getChannels'); renderChannels(); renderMessages(true); }
    if (name === 'status') { renderStatus(); renderObservers(); }
  }
  var tabBtns = document.querySelectorAll('.tab');
  for (var ti = 0; ti < tabBtns.length; ti++) {
    tabBtns[ti].addEventListener('click', function (e) { showScreen(e.currentTarget.getAttribute('data-screen')); });
  }

  // Knob (wheel): zoom the map, scroll lists
  window.addEventListener('wheel', function (e) {
    lastInteract = Date.now();
    if (!$('findPanel').classList.contains('hidden')) { $('fRes').scrollTop += (e.deltaY > 0 ? 1 : -1) * 100; return; }
    var dir = e.deltaY > 0 ? 1 : e.deltaY < 0 ? -1 : (e.deltaX > 0 ? 1 : -1);
    if (screen === 'map') zoom(dir > 0 ? -1 : 1);
    else if (screen === 'feed') $('feedList').scrollTop += dir * 120;
    else if (screen === 'mine') $('mineList').scrollTop += dir * 120;
    else if (screen === 'chan') $('msgList').scrollTop += dir * 90;
  }, { passive: true });

  // Hardware keys some DeskThing setups forward to apps
  window.addEventListener('keydown', function (e) {
    if (!$('findPanel').classList.contains('hidden')) return;
    var k = e.key || e.code;
    if (k === '1' || e.code === 'Digit1') showScreen('map');
    else if (k === '2' || e.code === 'Digit2') showScreen('feed');
    else if (k === '3' || e.code === 'Digit3') showScreen('chan');
    else if (k === '4' || e.code === 'Digit4') showScreen('mine');
    else if (k === 'Enter' && screen === 'map') recenter();
  });

  // ==========================================================
  // FEED
  // ==========================================================
  function feedDetail(f) {
    var parts = [];
    if (f.txt) parts.push(f.txt);
    parts.push(f.h + (f.h === 1 ? ' hop' : ' hops'));
    if (f.snr != null) parts.push('SNR ' + fmtSnr(f.snr));
    if (f.obs) parts.push('via ' + f.obs);
    return parts.join(' · ');
  }
  function renderMapFeed() {
    var html = '';
    var shown = [];
    for (var q = 0; q < feed.length && shown.length < 5; q++) if (passes(feed[q])) shown.push(feed[q]);
    var n = shown.length;
    for (var i = 0; i < n; i++) {
      var f = shown[i];
      html += '<div class="mf' + (f.mine ? ' mine' : '') + '"><div class="t"><i style="background:' + esc(f.c) + '"></i><span style="color:' + esc(f.c) + '">' + esc(f.t) + '</span><span class="ago mono">' + ago(f.ts) + '</span></div>' +
        '<div class="w">' + esc(f.who) + '</div><div class="d mono">' + esc(feedDetail(f)) + '</div></div>';
    }
    if (!n) html = '<div class="mf"><div class="w dim">Waiting for traffic…</div><div class="d">Streaks appear as packets are heard.</div></div>';
    $('mapFeed').innerHTML = html;
  }
  function renderFeed() {
    var vis = [];
    for (var q = 0; q < feed.length; q++) if (passes(feed[q])) vis.push(feed[q]);
    $('feedCount').textContent = vis.length + ' packets';
    if (screen !== 'feed') return;
    renderFilterBar();
    var html = '';
    for (var i = 0; i < vis.length; i++) {
      var f = vis[i];
      html += '<div class="fi' + (f.mine ? ' mine' : '') + '"><div class="chip2" style="color:' + esc(f.c) + '">' + esc(f.t) + '</div>' +
        '<div class="main"><div class="w">' + esc(f.who) + '</div><div class="d mono">' + esc(feedDetail(f)) + '</div></div>' +
        '<div class="r mono">' + ago(f.ts) + '</div></div>';
    }
    if (!vis.length) html = '<div class="empty">' + (feed.length ? 'Nothing matches the filter yet.' : 'No packets yet. If this stays empty, check the <b>STATUS</b> screen.') + '</div>';
    $('feedList').innerHTML = html;
  }

  // ==========================================================
  // FEED FILTER (applies to the feed lists and the map streaks)
  // ==========================================================
  var GROUPS = ['ADVERT', 'CHANNEL', 'DM', 'TRACE', 'PATH', 'CONTROL'];
  var filterOn = null; // null = default (server decides CONTROL from settings)
  function activeGroups() {
    if (filterOn) return filterOn;
    var g = GROUPS.slice(0, 5);
    if (cfg && cfg.showAcks) g.push('CONTROL');
    return g;
  }
  function groupOf(r) {
    if (r.g) return r.g;
    return ['ADVERT', 'CHANNEL', 'DM', 'TRACE', 'PATH'].indexOf(r.t) >= 0 ? r.t : 'CONTROL';
  }
  function passes(r) { return activeGroups().indexOf(groupOf(r)) >= 0; }
  function renderFilterBar() {
    var act = activeGroups(), all = act.length === GROUPS.length;
    var chips = document.querySelectorAll('.fchip');
    for (var i = 0; i < chips.length; i++) {
      var g = chips[i].getAttribute('data-g');
      chips[i].classList.toggle('on', g === 'ALL' ? all : act.indexOf(g) >= 0);
    }
    $('filterNote').textContent = all ? '' : act.length === 1 ? '· ' + act[0].toLowerCase() + ' only' : '· filtered (' + act.length + ' of 6)';
  }
  $('filterBar').addEventListener('click', function (e) {
    var t = e.target;
    while (t && t !== this && !t.getAttribute('data-g')) t = t.parentNode;
    if (!t || t === this) return;
    var g = t.getAttribute('data-g');
    var act = activeGroups().slice();
    if (g === 'ALL') act = act.length === GROUPS.length ? GROUPS.slice(0, 5) : GROUPS.slice();
    else {
      var i = act.indexOf(g);
      if (i >= 0) act.splice(i, 1); else act.push(g);
      if (!act.length) act = [g === 'ADVERT' ? 'CHANNEL' : 'ADVERT'];
    }
    filterOn = act;
    send('setFilter', { groups: act });
    renderFilterBar();
    renderFeed();
    renderMapFeed();
  });

  // ==========================================================
  // MY NODES
  // ==========================================================
  var STATUS_COLORS = { active: '#3DDC97', degraded: '#FFB547', silent: '#FF7A59' };
  function renderMine() {
    if (screen !== 'mine') return;
    var html = '';
    for (var i = 0; i < mineCards.length; i++) {
      var c = mineCards[i];
      var stText = c.status === 'active' ? 'Active' : c.status === 'degraded' ? 'Degraded' : 'Silent';
      html += '<div class="card"><div class="top2"><span class="sd" style="background:' + STATUS_COLORS[c.status || 'silent'] + '"></span>' +
        '<span class="nm">' + esc(c.n) + '</span><span class="rl">' + esc(String(c.r || '').toUpperCase()) + '</span></div>' +
        '<div class="st">' + stText + ' · heard ' + ago(c.last) + ' ago</div>' +
        '<div class="mets"><div class="met"><div class="mv mono">' + fmtSnr(c.snr) + '</div><div class="ml">AVG SNR</div></div>' +
        '<div class="met"><div class="mv mono">' + (c.today == null ? '-' : c.today) + '</div><div class="ml">PKTS TODAY</div></div>' +
        '<div class="met"><div class="mv mono">' + (c.obs == null ? '-' : c.obs) + '</div><div class="ml">OBSERVERS</div></div></div>' +
        '<div class="acts">' + (c.la != null ? '<button type="button" class="btn ghost" data-show="' + i + '">Show on map</button>' : '') +
        '<button type="button" class="btn ghost" data-remove="' + i + '">Remove</button></div></div>';
    }
    if (!mineCards.length) {
      html = '<div class="empty"><b>No nodes yet.</b><br>Tap a node on the map and press <b>★ Add to My Nodes</b>,<br>or list names in the DeskThing app under ScopeThing settings.</div>';
    }
    $('mineList').innerHTML = html;
  }
  $('mineList').addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.getAttribute) return;
    var si = t.getAttribute('data-show'), ri = t.getAttribute('data-remove');
    if (si != null) {
      var c = mineCards[+si];
      if (c && c.la != null) { showScreen('map'); setView(c.la, c.lo, Math.max(view.z, 12)); }
    } else if (ri != null) {
      var r = mineCards[+ri];
      if (r) { delete mineKeys[r.k]; pendingMine[r.k] = { on: false, until: Date.now() + 15000 }; mineCards.splice(+ri, 1); renderMine(); markBase(); send('toggleMyNode', { k: r.k, n: r.n, on: false }); }
    }
  });
  $('btnRefreshMine').addEventListener('click', function () { send('refreshMyNodes'); });

  // ==========================================================
  // STATUS
  // ==========================================================
  function renderStatus() {
    var s = lastStatus;
    var chip = $('connChip'), cls = 'chip-wait', label = 'Connecting';
    if (s.conn === 'live') { cls = 'chip-live'; label = 'LIVE'; }
    else if (s.conn === 'demo') { cls = 'chip-demo'; label = 'DEMO'; }
    else if (s.conn === 'error') { cls = 'chip-err'; label = 'OFFLINE'; }
    chip.className = 'chip ' + cls;
    $('connText').textContent = label;
    $('ppm').textContent = (s.ppm || 0) + ' pkt/min';
    $('stConn').textContent = label;
    $('stPpm').textContent = String(s.ppm || 0);
    $('stNodes').textContent = String(s.nodes || 0);
    $('stMsg').textContent = s.msg || '-';
    if (cfg) {
      $('stServer').textContent = cfg.demo ? 'Demo mode' : cfg.server;
      $('stVer').textContent = 'ScopeThing ' + (cfg.version || '?');
      $('stArea').textContent = cfg.repeaterName ? 'Repeater ' + cfg.repeaterName : cfg.areaLabel;
      $('stRadius').textContent = cfg.repeaterName ? 'n/a (repeater mode)' : cfg.radiusMi + ' mi';
    }
  }

  // ==========================================================
  // FIND NODE + @MENTIONS
  // ==========================================================
  var findQ = '';
  var findList = [];
  var findTimer = null;
  var KEYS = [['1','2','3','4','5','6','7','8','9','0'], ['Q','W','E','R','T','Y','U','I','O','P'], ['A','S','D','F','G','H','J','K','L','-'], ['Z','X','C','V','B','N','M','_','.','\u232B'], ['SPACE','CLEAR']];
  (function buildKbd() {
    var html = '';
    for (var r = 0; r < KEYS.length; r++) {
      html += '<div class="krow">';
      for (var c = 0; c < KEYS[r].length; c++) {
        var k = KEYS[r][c];
        html += '<button type="button" class="key' + (k.length > 1 && k !== '\u232B' ? ' wide' : '') + '" data-k="' + k + '">' + (k === 'SPACE' ? 'space' : k === 'CLEAR' ? 'clear' : k) + '</button>';
      }
      html += '</div>';
    }
    $('kbd').innerHTML = html;
  })();
  function renderFindQuery() {
    $('fQuery').textContent = findQ;
    $('fPh').style.display = findQ ? 'none' : 'inline';
  }
  function runFind() {
    if (findTimer) clearTimeout(findTimer);
    findTimer = setTimeout(function () { send('findNodes', { q: findQ }); }, 300);
  }
  $('kbd').addEventListener('click', function (e) {
    var t = e.target;
    while (t && t !== this && !t.getAttribute('data-k')) t = t.parentNode;
    if (!t || t === this) return;
    var k = t.getAttribute('data-k');
    if (k === '\u232B') findQ = findQ.slice(0, -1);
    else if (k === 'CLEAR') findQ = '';
    else if (k === 'SPACE') findQ += ' ';
    else if (findQ.length < 30) findQ += k.toLowerCase();
    renderFindQuery();
    runFind();
  });
  function renderWatchChips() {
    var html = '';
    for (var i = 0; i < watched.length; i++) {
      var w = watched[i];
      html += '<span class="wchip' + (w.src === 'picked' ? '' : ' dim') + '">@' + esc(w.n) + (w.src === 'picked' ? '<button type="button" class="x" data-unwatch="' + i + '" aria-label="Stop watching">\u00D7</button>' : ' · ' + (w.src === 'mynode' ? 'My Node' : 'settings')) + '</span>';
    }
    if (!watched.length) html = '<span class="dim" style="font-size:12px">Not watching any @mentions yet.</span>';
    $('fWatch').innerHTML = html;
  }
  function renderFindResults() {
    var html = '';
    for (var i = 0; i < findList.length; i++) {
      var n = findList[i];
      var mine = !!mineKeys[n.k], w = isWatched(n.k, n.n);
      html += '<div class="fr"><div class="main"><div class="nm">' + esc(n.n) + '</div><div class="sub mono">' + esc((n.r || 'node').toUpperCase()) + ' · ' + esc(n.k.slice(0, 8)) + (n.last ? ' · heard ' + ago(n.last) + ' ago' : '') + '</div></div>' +
        '<button type="button" class="b star' + (mine ? ' on' : '') + '" data-star="' + i + '" aria-label="My Nodes">\u2605</button>' +
        '<button type="button" class="b atb' + (w ? ' on' : '') + '" data-at="' + i + '">@ ' + (w ? 'On' : 'Watch') + '</button>' +
        (n.la != null ? '<button type="button" class="b" data-map="' + i + '">Map</button>' : '') + '</div>';
    }
    if (!findList.length) html = '<div class="empty" style="padding:24px 10px">' + (findQ ? 'No nodes match "' + esc(findQ) + '" yet.' : 'Start typing on the keyboard to find a node by name.') + '</div>';
    $('fRes').innerHTML = html;
  }
  $('fRes').addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.getAttribute) return;
    var si = t.getAttribute('data-star'), ai = t.getAttribute('data-at'), mi = t.getAttribute('data-map');
    if (si != null) {
      var n = findList[+si]; if (!n) return;
      var on = !mineKeys[n.k];
      if (on) mineKeys[n.k] = 1; else delete mineKeys[n.k];
      pendingMine[n.k] = { on: on, until: Date.now() + 15000 };
      send('toggleMyNode', { k: n.k, n: n.n, on: on });
      renderFindResults(); markBase();
    } else if (ai != null) {
      var a = findList[+ai]; if (!a) return;
      var w = isWatched(a.k, a.n);
      if (w && w.src !== 'picked') return;
      send('setMention', { k: a.k, n: a.n, on: !w });
    } else if (mi != null) {
      var m = findList[+mi]; if (!m) return;
      closeFind(); showScreen('map'); setView(m.la, m.lo, Math.max(view.z, 12));
    }
  });
  $('fWatch').addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.getAttribute) return;
    var ui = t.getAttribute('data-unwatch');
    if (ui == null) return;
    var w = watched[+ui];
    if (w) send('setMention', { k: w.k, n: w.n, on: false });
  });
  function openFind() {
    $('findPanel').classList.remove('hidden');
    renderFindQuery(); renderWatchChips(); renderFindResults();
    if (findQ) runFind();
  }
  function closeFind() { $('findPanel').classList.add('hidden'); }
  $('btnFind').addEventListener('click', openFind);
  $('btnFindClose').addEventListener('click', closeFind);
  on('found', function (d) {
    var p = d.payload;
    if (!p || p.q !== findQ) return; // ignore stale searches
    findList = p.list || [];
    renderFindResults();
  });
  on('mentions', function (d) {
    if (!Array.isArray(d.payload)) return;
    watched = d.payload;
    updateWatchBtn();
    if (!$('findPanel').classList.contains('hidden')) { renderWatchChips(); renderFindResults(); }
  });

  // ==========================================================
  // CHANNELS
  // ==========================================================
  var channels = [];
  var selCh = null;
  var msgs = {};        // channel key -> [messages]
  var unreadCh = {};    // channel key -> count
  var unreadTotal = 0;
  var msgLoading = false;

  function chKey(name) { return String(name || '').toLowerCase().replace(/^#/, ''); }
  function updateBadge() {
    var b = $('chanBadge');
    if (unreadTotal > 0 && screen !== 'chan') { b.textContent = unreadTotal > 99 ? '99+' : String(unreadTotal); b.classList.remove('hidden'); }
    else b.classList.add('hidden');
  }
  function renderChannels() {
    if (screen !== 'chan') return;
    var html = '';
    for (var i = 0; i < channels.length; i++) {
      var c = channels[i], k = chKey(c.n), un = unreadCh[k];
      html += '<button type="button" class="ch' + (selCh && chKey(selCh.n) === k ? ' on' : '') + '" data-ch="' + i + '">' +
        '<div class="t1"><span class="nm">' + esc(c.n) + '</span>' + (un ? '<span class="dotnew"></span>' : '') + '<span class="ag mono">' + (c.ts ? ago(c.ts) : '') + '</span></div>' +
        '<div class="t2">' + (c.who ? '<b>' + esc(c.who) + ':</b> ' : '') + esc(c.last || (c.cnt + ' messages')) + '</div></button>';
    }
    if (!channels.length) html = '<div class="empty" style="padding:30px 10px">Loading channels…</div>';
    $('chanList').innerHTML = html;
  }
  function renderMessages(scrollToEnd) {
    if (screen !== 'chan') return;
    var box = $('msgList');
    var nearEnd = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
    if (!selCh) {
      $('chanName').textContent = 'Channels';
      $('chanSub').textContent = 'Tap a channel on the left';
      box.innerHTML = '<div class="empty">Messages heard by CoreScope observers show here, live.</div>';
      return;
    }
    var list = msgs[chKey(selCh.n)] || [];
    $('chanName').textContent = selCh.n;
    $('chanSub').textContent = msgLoading ? 'Loading…' : (selCh.cnt ? selCh.cnt + ' messages total · ' : '') + 'showing last ' + list.length;
    var html = '';
    for (var i = 0; i < list.length; i++) {
      var m = list[i];
      var heard = [];
      if (m.obs && m.obs.length) heard.push('heard by ' + m.obs.slice(0, 3).join(', ') + (m.obs.length > 3 ? ' +' + (m.obs.length - 3) : ''));
      if (m.hops != null) heard.push(m.hops + (m.hops === 1 ? ' hop' : ' hops'));
      if (m.snr != null) heard.push('SNR ' + fmtSnr(m.snr));
      if (m.rep > 1) heard.push(m.rep + ' copies');
      html += '<div class="msg' + (m.fresh && Date.now() - m.ts < 15000 ? ' new' : '') + '"><div class="mh"><span class="who">' + esc(m.who) + '</span><span class="tm mono">' + ago(m.ts) + ' ago</span></div>' +
        '<div class="bd">' + esc(m.text) + '</div><div class="heard mono">' + esc(heard.join(' · ')) + '</div></div>';
    }
    if (!list.length) html = '<div class="empty">' + (msgLoading ? 'Loading messages…' : 'No messages yet.') + '</div>';
    box.innerHTML = html;
    if (scrollToEnd || nearEnd) box.scrollTop = box.scrollHeight;
  }
  $('chanList').addEventListener('click', function (e) {
    var t = e.target;
    while (t && t !== this && !t.getAttribute('data-ch')) t = t.parentNode;
    if (!t || t === this) return;
    var c = channels[+t.getAttribute('data-ch')];
    if (!c) return;
    selCh = c;
    var k = chKey(c.n);
    if (unreadCh[k]) { delete unreadCh[k]; }
    msgLoading = !msgs[k];
    send('getMessages', { h: c.h });
    renderChannels();
    renderMessages(true);
  });

  on('channels', function (d) {
    if (!Array.isArray(d.payload)) return;
    channels = d.payload;
    if (selCh) for (var i = 0; i < channels.length; i++) if (chKey(channels[i].n) === chKey(selCh.n)) selCh = channels[i];
    if (!selCh && channels.length && screen === 'chan') { /* wait for a tap */ }
    renderChannels();
  });

  on('messages', function (d) {
    var p = d.payload;
    if (!p || !p.h) return;
    var k = chKey(p.h);
    if (selCh && chKey(selCh.h) === k) k = chKey(selCh.n);
    var live = msgs[k] || [];
    var list = p.list || [];
    // keep live messages that arrived after the history snapshot
    var lastTs = list.length ? list[list.length - 1].ts : 0;
    for (var i = 0; i < live.length; i++) if (live[i].ts > lastTs && live[i].fresh) list.push(live[i]);
    msgs[k] = list.slice(-80);
    if (selCh && chKey(selCh.n) === k) msgLoading = false;
    renderMessages(true);
  });

  on('chanmsg', function (d) {
    var m = d.payload;
    if (!m || !m.ch) return;
    var k = chKey(m.ch);
    var list = msgs[k] || (msgs[k] = []);
    // the same transmission is reported once per observer: merge them
    var hit = null;
    for (var i = list.length - 1; i >= 0 && i >= list.length - 15; i--) {
      if ((m.id && list[i].id === m.id) || (list[i].who === m.who && list[i].text === m.text && Math.abs(list[i].ts - m.ts) < 120000)) { hit = list[i]; break; }
    }
    if (hit) {
      hit.rep = (hit.rep || 1) + 1;
      if (m.obs) { hit.obs = hit.obs || []; if (hit.obs.indexOf(m.obs) < 0) hit.obs.push(m.obs); }
    } else {
      list.push({ id: m.id, who: m.who, text: m.text, ts: m.ts, obs: m.obs ? [m.obs] : [], hops: m.hops, snr: m.snr, rep: 1, fresh: true });
      if (list.length > 80) list.splice(0, list.length - 80);
      // bump channel in the list
      var found = false;
      for (var j = 0; j < channels.length; j++) {
        if (chKey(channels[j].n) === k) { channels[j].last = m.text; channels[j].who = m.who; channels[j].ts = m.ts; channels[j].cnt = (channels[j].cnt || 0) + 1; found = true; channels.unshift(channels.splice(j, 1)[0]); break; }
      }
      if (!found) channels.unshift({ h: m.ch, n: m.ch, last: m.text, who: m.who, cnt: 1, ts: m.ts });
      var viewing = screen === 'chan' && selCh && chKey(selCh.n) === k;
      if (!viewing) { unreadCh[k] = (unreadCh[k] || 0) + 1; if (screen !== 'chan') unreadTotal++; }
      updateBadge();
    }
    renderChannels();
    if (screen === 'chan' && selCh && chKey(selCh.n) === k) renderMessages(false);
  });

  // ==========================================================
  // OBSERVERS (status screen)
  // ==========================================================
  var observersList = [];
  function renderObservers() {
    if (screen !== 'status') return;
    var html = '', online = 0;
    for (var i = 0; i < observersList.length; i++) {
      var o = observersList[i];
      var age = o.last ? Date.now() - o.last : Infinity;
      var col = age < 15 * 60e3 ? '#3DDC97' : age < 6 * 3600e3 ? '#FFB547' : '#FF7A59';
      if (age < 15 * 60e3) online++;
      html += '<div class="ob"><span class="od" style="background:' + col + '"></span><span class="on">' + esc(o.n) + '</span>' +
        '<span class="oi mono">' + (o.iata ? esc(o.iata) + ' · ' : '') + o.pkh + '/h · ' + ago(o.last) + '</span></div>';
    }
    if (!observersList.length) html = '<div class="dim" style="font-size:13px;padding:10px 0">No observer list yet.</div>';
    $('obsList').innerHTML = html;
    $('obsCount').textContent = online + ' online / ' + observersList.length;
  }
  on('observers', function (d) { if (Array.isArray(d.payload)) { observersList = d.payload; renderObservers(); } });

  // ==========================================================
  // AMBIENT MODE (full-screen map, dims at night)
  // ==========================================================
  function setMapHeight(h) {
    H = h;
    baseCanvas.height = h; fxCanvas.height = h;
    updateCenterW(); requestTiles(); markBase();
  }
  function enterAmbient() {
    if (ambient) return;
    ambient = true;
    hideNodeCard();
    $('alertsPanel').classList.add('hidden');
    if (screen !== 'map') showScreen('map');
    document.getElementById('app').classList.add('ambient');
    setMapHeight(480);
    updateDim(); renderAmbientHud();
  }
  function exitAmbient() {
    if (!ambient) return;
    ambient = false;
    lastInteract = Date.now();
    var app = document.getElementById('app');
    app.classList.remove('ambient'); app.classList.remove('dim');
    $('alertBanner').style.top = '8px';
    setMapHeight(388);
  }
  function toggleAmbient() { if (ambient) exitAmbient(); else enterAmbient(); }
  $('btnAmbient').addEventListener('click', function (e) { e.stopPropagation(); enterAmbient(); });
  $('ambientHud').addEventListener('click', exitAmbient);

  // Sun altitude (degrees) at the watched area, for "dim after sunset"
  function sunAltitude(lat, lon, date) {
    var rad = Math.PI / 180, d = date / 86400000 - 10957.5;
    var g = (357.529 + 0.98560028 * d) * rad;
    var q = 280.459 + 0.98564736 * d;
    var L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * rad;
    var e = (23.439 - 0.00000036 * d) * rad;
    var ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L));
    var dec = Math.asin(Math.sin(e) * Math.sin(L));
    var gmst = (18.697374558 + 24.06570982441908 * d) % 24;
    var ha = (gmst * 15 + lon) * rad - ra;
    return Math.asin(Math.sin(lat * rad) * Math.sin(dec) + Math.cos(lat * rad) * Math.cos(dec) * Math.cos(ha)) / rad;
  }
  var undimUntil = 0;
  function updateDim() {
    var app = document.getElementById('app');
    var mode = cfg && cfg.dimMode ? cfg.dimMode : 'auto';
    var dark = false;
    if (ambient && Date.now() > undimUntil) {
      if (mode === 'always') dark = true;
      else if (mode === 'auto' && cfg && cfg.center) dark = sunAltitude(cfg.center[0], cfg.center[1], Date.now()) < -6;
    }
    app.classList.toggle('dim', dark);
  }
  function renderAmbientHud() {
    if (!ambient) return;
    var d = new Date(), p2 = function (n) { return (n < 10 ? '0' : '') + n; };
    var h = d.getHours(), ampm = h >= 12 ? 'PM' : 'AM';
    $('aTime').textContent = ((h % 12) || 12) + ':' + p2(d.getMinutes());
    $('aUtc').textContent = ampm + '  ·  ' + p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + 'Z';
    if (cfg) $('aArea').textContent = (cfg.repeaterName ? '\u25C6 ' + cfg.repeaterName : cfg.areaLabel) + '  ·  ' + (lastStatus.ppm || 0) + ' pkt/min';
    var f = null;
    for (var i = 0; i < feed.length; i++) if (passes(feed[i])) { f = feed[i]; break; }
    $('aTicker').innerHTML = f ? '<b style="color:' + esc(f.c) + '">' + esc(f.t) + '</b>' + esc(f.who) + (f.txt ? ' \u2014 ' + esc(f.txt) : '') + ' <span class="dim">' + ago(f.ts) + ' ago</span>' : '<span class="dim">Listening for traffic\u2026</span>';
  }

  // Idle tracking for auto-ambient (and so the knob/touch wake things up)
  function touched() { lastInteract = Date.now(); }
  ['touchstart', 'mousedown', 'keydown'].forEach(function (ev) { window.addEventListener(ev, touched, { passive: true }); });
  setInterval(function () {
    var mins = cfg && cfg.ambientIdleMin != null ? cfg.ambientIdleMin : 5;
    if (!ambient && mins > 0 && Date.now() - lastInteract > mins * 60000) enterAmbient();
    updateDim();
    renderAmbientHud();
  }, 10000);

  // ==========================================================
  // ALERTS
  // ==========================================================
  var alerts = [];
  var unseenAlerts = 0;
  var bannerTimer = null;
  var bannerAlert = null;
  function updateBell() {
    var b = $('btnBell'), c = $('bellCount');
    b.classList.toggle('has', unseenAlerts > 0);
    if (unseenAlerts > 0) { c.textContent = unseenAlerts > 99 ? '99+' : String(unseenAlerts); c.classList.remove('hidden'); }
    else c.classList.add('hidden');
  }
  function showBanner(a) {
    bannerAlert = a;
    // in ambient mode the clock lives top-left, so the banner goes near the bottom
    $('alertBanner').style.top = ambient ? '340px' : '8px';
    $('abBar').style.background = a.color || '#39D0FF';
    $('abTitle').textContent = a.title;
    $('abText').textContent = a.body || '';
    $('alertBanner').classList.remove('hidden');
    var fl = $('flash');
    fl.style.borderColor = a.color || '#39D0FF';
    fl.classList.remove('go'); void fl.offsetWidth; fl.classList.add('go');
    if (bannerTimer) clearTimeout(bannerTimer);
    bannerTimer = setTimeout(function () { $('alertBanner').classList.add('hidden'); bannerAlert = null; }, 9000);
  }
  function openAlert(a) {
    if (!a) return;
    $('alertBanner').classList.add('hidden');
    $('alertsPanel').classList.add('hidden');
    exitAmbient();
    if (a.openChannel && a.ch) {
      showScreen('chan');
      for (var j = 0; j < channels.length; j++) {
        if (chKey(channels[j].n) === chKey(a.ch)) { selCh = channels[j]; send('getMessages', { h: channels[j].h }); renderChannels(); renderMessages(true); break; }
      }
    } else if (a.la != null && a.lo != null) {
      showScreen('map');
      setView(a.la, a.lo, Math.max(view.z, 12));
    } else if (a.ch) {
      showScreen('chan');
      for (var i = 0; i < channels.length; i++) {
        if (chKey(channels[i].n) === chKey(a.ch)) { selCh = channels[i]; send('getMessages', { h: channels[i].h }); renderChannels(); renderMessages(true); break; }
      }
    }
  }
  $('alertBanner').addEventListener('click', function () { openAlert(bannerAlert); });
  function renderAlerts() {
    var html = '';
    for (var i = 0; i < alerts.length; i++) {
      var a = alerts[i];
      html += '<div class="al" data-al="' + i + '"><span class="bar" style="background:' + esc(a.color) + '"></span><div class="main"><div class="t">' + esc(a.title) + '</div><div class="b">' + esc(a.body) + '</div></div><div class="r mono">' + ago(a.ts) + '</div></div>';
    }
    if (!alerts.length) html = '<div class="empty">No alerts yet.<br>Set them up in the DeskThing app under ScopeThing settings (My Nodes, keywords, new nodes).</div>';
    $('alertsList').innerHTML = html;
  }
  $('alertsList').addEventListener('click', function (e) {
    var t = e.target;
    while (t && t !== this && !t.getAttribute('data-al')) t = t.parentNode;
    if (t && t !== this) openAlert(alerts[+t.getAttribute('data-al')]);
  });
  $('btnBell').addEventListener('click', function () {
    var pnl = $('alertsPanel');
    var opening = pnl.classList.contains('hidden');
    pnl.classList.toggle('hidden', !opening);
    if (opening) { unseenAlerts = 0; updateBell(); renderAlerts(); }
  });
  $('btnAlertsClose').addEventListener('click', function () { $('alertsPanel').classList.add('hidden'); });
  $('btnAlertsClear').addEventListener('click', function () { alerts = []; renderAlerts(); });
  $('btnAlertsTest').addEventListener('click', function () { send('testAlert'); });
  on('alert', function (d) {
    var a = d.payload;
    if (!a || !a.title) return;
    alerts.unshift(a);
    if (alerts.length > 40) alerts.length = 40;
    unseenAlerts++;
    updateBell();
    if (ambient) { undimUntil = Date.now() + 20000; updateDim(); }
    showBanner(a);
    if (!$('alertsPanel').classList.contains('hidden')) renderAlerts();
  });

  // ==========================================================
  // SERVER MESSAGES
  // ==========================================================
  var gotConfig = false;
  on('config', function (d) {
    var c = d.payload;
    if (!c || !c.center) return;
    var styleChanged = !cfg || cfg.mapStyle !== c.mapStyle;
    var centerChanged = !cfg || cfg.center[0] !== c.center[0] || cfg.center[1] !== c.center[1] || cfg.radiusMi !== c.radiusMi;
    cfg = c;
    gotConfig = true;
    if (filterOn) send('setFilter', { groups: filterOn });
    if (styleChanged) { tiles = {}; tilePending = {}; }
    $('areaChip').textContent = c.repeaterName ? '◆ ' + c.repeaterName : c.areaLabel + ' · ' + c.radiusMi + ' mi';
    $('attrib').textContent = c.attrib ? 'Data: CoreScope · ' + c.attrib : 'Data: CoreScope';
    if (centerChanged) {
      homeView = { lat: c.center[0], lon: c.center[1], z: fitZoom(c.center[0], c.repeaterName ? Math.min(c.radiusMi, 30) : c.radiusMi) };
      recenter();
    } else { requestTiles(); markBase(); }
    renderStatus();
    updateDim();
  });

  on('nodes', function (d) {
    if (!Array.isArray(d.payload)) return;
    nodes = d.payload;
    for (var i = 0; i < nodes.length; i++) if (nodes[i].m && !(pendingMine[nodes[i].k] && !pendingMine[nodes[i].k].on)) mineKeys[nodes[i].k] = 1;
    markBase();
  });

  on('tile', function (d) {
    var t = d.payload;
    if (!t || !cfg || t.style !== cfg.mapStyle) return;
    var key = t.style + '/' + t.z + '/' + t.x + '/' + t.y;
    var img = new Image();
    img.onload = function () {
      var out = img;
      if (cfg.darken) {
        // Turn light OpenStreetMap tiles into a dark map, once per tile
        var c = document.createElement('canvas');
        c.width = TILE; c.height = TILE;
        var g = c.getContext('2d');
        var canFilter = typeof g.filter === 'string';
        if (canFilter) g.filter = 'invert(1) hue-rotate(180deg) brightness(0.9) contrast(0.85) saturate(0.6)';
        g.drawImage(img, 0, 0, TILE, TILE);
        if (!canFilter) { g.fillStyle = 'rgba(10,14,19,0.65)'; g.fillRect(0, 0, TILE, TILE); }
        out = c;
      }
      tiles[key] = out;
      delete tilePending[key];
      var count = 0;
      for (var k in tiles) if (tiles.hasOwnProperty(k)) count++;
      if (count > 160) { // keep memory low on the Car Thing
        for (var k2 in tiles) { if (tiles.hasOwnProperty(k2) && k2.split('/')[1] !== String(view.z)) { delete tiles[k2]; if (--count <= 120) break; } }
      }
      if (t.z === view.z) markBase();
    };
    img.src = t.d;
  });

  on('route', function (d) {
    var r = d.payload;
    if (!r || !r.p || !r.p.length || paused) return;
    if (screen === 'map' && passes(r)) addRoute(r);
    if (r.feed) {
      feed.unshift(r);
      if (ambient) renderAmbientHud();
      if (feed.length > 60) feed.length = 60;
      if (screen === 'map') renderMapFeed();
      else if (screen === 'feed') renderFeed();
    }
  });

  on('mynodes', function (d) {
    if (!Array.isArray(d.payload)) return;
    var now = Date.now();
    var cards = d.payload, have = {};
    for (var c0 = 0; c0 < cards.length; c0++) have[cards[c0].k] = 1;
    // a just-tapped change wins until the server's list reflects it
    for (var pk in pendingMine) {
      if (!pendingMine.hasOwnProperty(pk)) continue;
      var pm = pendingMine[pk];
      if (now > pm.until || !!have[pk] === pm.on) { delete pendingMine[pk]; continue; }
      if (!pm.on) cards = cards.filter(function (c) { return c.k !== pk; });
    }
    mineCards = cards;
    mineKeys = {};
    for (var i = 0; i < mineCards.length; i++) mineKeys[mineCards[i].k] = 1;
    for (var pk2 in pendingMine) if (pendingMine.hasOwnProperty(pk2) && pendingMine[pk2].on) mineKeys[pk2] = 1;
    updateStarBtn();
    markBase();
    renderMine();
  });

  on('status', function (d) { if (d.payload) { lastStatus = d.payload; renderStatus(); } });

  on('cmd', function (d) {
    var c = d.payload && d.payload.cmd;
    if (c === 'screenMap') showScreen('map');
    else if (c === 'screenFeed') showScreen('feed');
    else if (c === 'screenMyNodes') showScreen('mine');
    else if (c === 'screenChannels') showScreen('chan');
    else if (c === 'screenStatus') showScreen('status');
    else if (c === 'nextScreen') showScreen(SCREENS[(SCREENS.indexOf(screen) + 1) % SCREENS.length]);
    else if (c === 'zoomIn') zoom(1);
    else if (c === 'zoomOut') zoom(-1);
    else if (c === 'recenter') recenter();
    else if (c === 'togglePause') togglePause();
    else if (c === 'toggleAmbient') toggleAmbient();
    if (c !== 'toggleAmbient') { lastInteract = Date.now(); if (ambient && c && c.indexOf('zoom') !== 0) exitAmbient(); }
  });

  // ==========================================================
  // TIMERS + STARTUP
  // ==========================================================
  function tickClock() {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    $('clock').textContent = p(d.getUTCHours()) + ':' + p(d.getUTCMinutes()) + ':' + p(d.getUTCSeconds()) + 'Z';
  }
  setInterval(tickClock, 1000);
  tickClock();
  setInterval(function () {
    if (screen === 'map') renderMapFeed();
    else if (screen === 'feed') renderFeed();
    else if (screen === 'chan') { renderChannels(); renderMessages(false); }
    else if (screen === 'status') renderObservers();
    // retry tiles that never arrived
    var now = Date.now();
    for (var k in tilePending) if (tilePending.hasOwnProperty(k) && now - tilePending[k] > 15000) delete tilePending[k];
    if (screen === 'map') requestTiles();
  }, 5000);

  updateCenterW();
  renderMapFeed();
  markBase();
  send('hello');
  var helloTries = 0;
  var helloTimer = setInterval(function () {
    if (gotConfig || ++helloTries > 20) { clearInterval(helloTimer); return; }
    send('hello');
  }, 3000);
})();
