import { defineConfig } from 'vite'

// The DeskThing CLI adds @vitejs/plugin-legacy (Chrome 69) and sets the output
// folder itself, so this file only needs the relative base path.
export default defineConfig({
  base: './'
})
