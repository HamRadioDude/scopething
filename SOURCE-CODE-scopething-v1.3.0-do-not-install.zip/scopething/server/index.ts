// ScopeThing - CoreScope live mesh map for the Spotify Car Thing (DeskThing)
// Server side: runs on the PC. Connects to a CoreScope server, filters packets
// to the watched area or repeater, resolves hop paths to coordinates, and sends
// small "route" messages to the Car Thing, which draws the streaks.
//
// Follows the HamThing DeskThing guide: DESKTHING_EVENTS enum, async start/stop,
// initSettings first, only START/STOP registered at module level, sync wrappers
// around async work in timers.

import { DeskThing } from '@deskthing/server'
import { DESKTHING_EVENTS, SETTING_TYPES } from '@deskthing/types'
import WebSocket from 'ws'

const TAG = '[ScopeThing]'
const APP_VERSION = '1.3.0'
const UA = 'ScopeThing/1.0 (DeskThing app; github.com/HamRadioDude/HamThing)'

// ============================================================
// TYPES
// ============================================================
type LatLon = [number, number]

interface MeshNode {
  key: string // full public key, lower case
  name: string
  role: string
  lat: number | null
  lon: number | null
  last: number // ms epoch, 0 if unknown
}

interface Config {
  serverUrl: string
  area: string
  radiusMi: number
  watchRepeater: string
  myNodesText: string
  mapStyle: string
  tileKey: string
  showAcks: boolean
  demo: boolean
  alertMyNodes: boolean
  quietMin: number
  silentHours: number
  keywords: string[]
  alertNewNodes: boolean
  ambientIdleMin: number
  dimMode: string
  mentionNames: string[]
  mentionMyNodes: boolean
}

// ============================================================
// CONSTANTS
// ============================================================
const TYPE_INFO: Record<string, { label: string; color: string }> = {
  ADVERT: { label: 'ADVERT', color: '#FFB547' },
  GRP_TXT: { label: 'CHANNEL', color: '#39D0FF' },
  TXT_MSG: { label: 'DM', color: '#5EEAD4' },
  TRACE: { label: 'TRACE', color: '#B78CFF' },
  PATH: { label: 'PATH', color: '#3DDC97' },
  GRP_DATA: { label: 'DATA', color: '#7FB4FF' },
  ACK: { label: 'ACK', color: '#8B98A8' },
  REQ: { label: 'REQ', color: '#8B98A8' },
  RESPONSE: { label: 'RESP', color: '#8B98A8' },
  ANON_REQ: { label: 'REQ', color: '#8B98A8' }
}
const QUIET_TYPES = ['ACK', 'REQ', 'RESPONSE', 'ANON_REQ']
const FILTER_GROUPS = ['ADVERT', 'CHANNEL', 'DM', 'TRACE', 'PATH', 'CONTROL']
// Feed/map filter chosen on the Car Thing (null = default: everything but CONTROL unless "Show ACK" is on)
let clientGroups: string[] | null = null
const groupOf = (label: string): string => (['ADVERT', 'CHANNEL', 'DM', 'TRACE', 'PATH'].indexOf(label) >= 0 ? label : 'CONTROL')

// CARTO raster tiles need a (free) API key since 2026. Without one we use the
// standard OpenStreetMap tiles; the Car Thing darkens them for the dark style.
const CARTO_URLS: Record<string, string> = {
  dark: 'https://basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png?key={key}',
  light: 'https://basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png?key={key}'
}
const OSM_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
const tileSource = (): 'carto' | 'osm' | 'none' => (cfg.mapStyle === 'none' ? 'none' : cfg.tileKey ? 'carto' : 'osm')
const TILE_CACHE_MAX = 400
const MAX_ROUTES_PER_SEC = 12
const MAX_HOP_MILES = 250

// ============================================================
// STATE
// ============================================================
let cfg: Config = {
  serverUrl: 'https://corescope.chicagolandmesh.org',
  area: 'Chicago, IL',
  radiusMi: 60,
  watchRepeater: '',
  myNodesText: '',
  mapStyle: 'dark',
  tileKey: '',
  showAcks: false,
  demo: false,
  alertMyNodes: true,
  quietMin: 60,
  silentHours: 6,
  keywords: [],
  alertNewNodes: false,
  ambientIdleMin: 5,
  dimMode: 'auto',
  mentionNames: [],
  mentionMyNodes: true
}

let center: LatLon = [41.8781, -87.6298]
let areaLabel = 'Chicago, IL'
let repeaterKey = '' // full key of the watched repeater, if any
let repeaterName = ''

const nodes = new Map<string, MeshNode>()
const observers = new Map<string, { name: string; lat: number | null; lon: number | null; iata?: string; last?: number; pkh?: number; cnt?: number }>()
let channelTimer: ReturnType<typeof setInterval> | null = null
let savedMyNodes: { key: string; name: string }[] = []
let geoCache: Record<string, { ll: LatLon; label: string }> = {}
let savedMentions: { key: string; name: string }[] = []
const persist = () => {
  try {
    DeskThing.saveData({ myNodes: savedMyNodes, geoCache, mentions: savedMentions })
  } catch (e) {
    console.error(`${TAG} saveData failed`, e)
  }
}
let myNodeKeys: string[] = []
let myNodeCards: any[] = []

let ws: WebSocket | null = null
let wsTimer: ReturnType<typeof setTimeout> | null = null
let wsWatchdog: ReturnType<typeof setInterval> | null = null
let wsLastMsg = 0
let wsBackoff = 2000
let firstPacketLogged = false
let livePackets = 0
let routesSent = 0
let lastReport = 0
let running = false
let unsubs: (() => void)[] = []

let status = { conn: 'starting', msg: 'Starting...', ppm: 0, nodes: 0 }
const pktTimes: number[] = []

let nodeTimer: ReturnType<typeof setInterval> | null = null
let myNodesTimer: ReturnType<typeof setInterval> | null = null
let statusTimer: ReturnType<typeof setInterval> | null = null
let demoTimer: ReturnType<typeof setTimeout> | null = null
let settingsDebounce: ReturnType<typeof setTimeout> | null = null

let routeBudget = MAX_ROUTES_PER_SEC
let budgetTimer: ReturnType<typeof setInterval> | null = null
const recentHashes = new Map<string, number>()

const tileCache = new Map<string, string>()
const tilePending = new Set<string>()

// ============================================================
// HELPERS
// ============================================================
const num = (v: any): number | null => {
  const n = typeof v === 'string' ? parseFloat(v) : v
  return typeof n === 'number' && isFinite(n) ? n : null
}

const validLL = (lat: any, lon: any): boolean => {
  const a = num(lat)
  const b = num(lon)
  return a !== null && b !== null && !(a === 0 && b === 0) && Math.abs(a) <= 90 && Math.abs(b) <= 180
}

const milesBetween = (a: LatLon, b: LatLon): number => {
  const R = 3958.8
  const toRad = Math.PI / 180
  const dLat = (b[0] - a[0]) * toRad
  const dLon = (b[1] - a[1]) * toRad
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * toRad) * Math.cos(b[0] * toRad) * Math.sin(dLon / 2) ** 2
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)))
}

const parseMaybeJSON = (v: any): any => {
  if (typeof v !== 'string') return v
  try {
    return JSON.parse(v)
  } catch {
    return null
  }
}

const parseTime = (v: any): number => {
  if (!v) return 0
  const t = Date.parse(String(v))
  return isNaN(t) ? 0 : t
}

const baseUrl = (): string => cfg.serverUrl.trim().replace(/\/+$/, '')

const apiGet = async (path: string, timeoutMs = 15000): Promise<any> => {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), timeoutMs)
  try {
    const res = await fetch(baseUrl() + path, { headers: { 'User-Agent': UA, Accept: 'application/json' }, signal: ctrl.signal })
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${path}`)
    return await res.json()
  } finally {
    clearTimeout(t)
  }
}

const send = (type: string, payload: any) => {
  try {
    DeskThing.send({ type, payload })
  } catch (e) {
    console.error(`${TAG} send error`, e)
  }
}

const setStatus = (conn: string, msg: string) => {
  status.conn = conn
  status.msg = msg
  sendStatus()
}

const sendStatus = () => {
  const now = Date.now()
  while (pktTimes.length && now - pktTimes[0] > 60000) pktTimes.shift()
  status.ppm = pktTimes.length
  status.nodes = nodes.size
  if (now - lastReport >= 60000 && running) {
    lastReport = now
    console.log(`${TAG} Last minute: ${status.ppm} packets heard, ${routesSent} in your area sent to Car Thing (${status.conn})`)
    routesSent = 0
  }
  send('status', status)
}

// ============================================================
// SETTINGS
// ============================================================
const initializeSettings = async () => {
  const settings: any = {
    server_url: {
      id: 'server_url',
      type: SETTING_TYPES.STRING,
      value: cfg.serverUrl,
      label: 'CoreScope server',
      description: 'Address of a CoreScope server, e.g. https://corescope.chicagolandmesh.org'
    },
    area: {
      id: 'area',
      type: SETTING_TYPES.STRING,
      value: cfg.area,
      label: 'Area to watch',
      description: 'City, zip code, or "lat, lon". Example: Naperville, IL  or  41.88, -87.63'
    },
    radius_mi: {
      id: 'radius_mi',
      type: SETTING_TYPES.NUMBER,
      value: cfg.radiusMi,
      label: 'Radius (miles)',
      min: 5,
      max: 500,
      step: 5,
      description: 'Only show traffic that touches this circle'
    },
    watch_repeater: {
      id: 'watch_repeater',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'Watch one repeater (optional)',
      description: 'Repeater name or key prefix. When set, only packets through this repeater are shown and the map centers on it.'
    },
    my_nodes: {
      id: 'my_nodes',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'My Nodes',
      description: 'Comma-separated node names or key prefixes. You can also star nodes on the Car Thing.'
    },
    map_style: {
      id: 'map_style',
      type: SETTING_TYPES.SELECT,
      value: 'dark',
      label: 'Map style',
      options: [
        { label: 'Dark map', value: 'dark' },
        { label: 'Light map', value: 'light' },
        { label: 'No map (grid only, least data)', value: 'none' }
      ]
    },
    map_key: {
      id: 'map_key',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'CARTO map key (optional)',
      description: 'Leave blank to use OpenStreetMap tiles. For CARTO dark/light maps, get a free key at carto.com/basemaps/apikey and paste it here.'
    },
    show_acks: {
      id: 'show_acks',
      type: SETTING_TYPES.BOOLEAN,
      value: false,
      label: 'Show ACK / request traffic',
      description: 'Off keeps the map focused on adverts, messages and traces'
    },
    alert_my_nodes: {
      id: 'alert_my_nodes',
      type: SETTING_TYPES.BOOLEAN,
      value: true,
      label: 'Alert: My Nodes',
      description: 'Flash an alert when one of My Nodes comes back on the air, or goes silent'
    },
    alert_quiet_min: {
      id: 'alert_quiet_min',
      type: SETTING_TYPES.NUMBER,
      value: 60,
      label: 'Alert: "back on air" after quiet (minutes)',
      min: 5,
      max: 1440,
      step: 5,
      description: 'A My Node heard again after being quiet this long triggers an alert'
    },
    alert_silent_hours: {
      id: 'alert_silent_hours',
      type: SETTING_TYPES.NUMBER,
      value: 6,
      label: 'Alert: "gone silent" after (hours)',
      min: 1,
      max: 72,
      step: 1,
      description: 'A My Node not heard for this long triggers an alert (once)'
    },
    alert_keywords: {
      id: 'alert_keywords',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'Alert: channel keywords',
      description: 'Comma-separated words or callsigns, e.g. DUDETESTED, net, help. Any channel message containing one triggers an alert.'
    },
    alert_mentions: {
      id: 'alert_mentions',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'Alert: @mentions of these nodes',
      description: 'Comma-separated node names. A channel message that @mentions one (like @[Ridge-RPT] or @Ridge-RPT) pops up an alert. You can also pick nodes on the Car Thing (My Nodes > Find node).'
    },
    alert_mention_my_nodes: {
      id: 'alert_mention_my_nodes',
      type: SETTING_TYPES.BOOLEAN,
      value: true,
      label: 'Alert: @mentions of My Nodes',
      description: 'Also alert when any of My Nodes is @mentioned in a channel'
    },
    alert_new_nodes: {
      id: 'alert_new_nodes',
      type: SETTING_TYPES.BOOLEAN,
      value: false,
      label: 'Alert: new nodes in my area',
      description: 'Alert when a node never seen before adverts inside your area'
    },
    ambient_idle_min: {
      id: 'ambient_idle_min',
      type: SETTING_TYPES.NUMBER,
      value: 5,
      label: 'Ambient mode after idle (minutes)',
      min: 0,
      max: 120,
      step: 1,
      description: 'Full-screen map after this many minutes without touching the Car Thing. 0 = only when you press the ambient button.'
    },
    dim_mode: {
      id: 'dim_mode',
      type: SETTING_TYPES.SELECT,
      value: 'auto',
      label: 'Dim at night',
      options: [
        { label: 'Auto (after sunset at your area)', value: 'auto' },
        { label: 'Always dim in ambient mode', value: 'always' },
        { label: 'Never dim', value: 'off' }
      ]
    },
    demo_mode: {
      id: 'demo_mode',
      type: SETTING_TYPES.BOOLEAN,
      value: false,
      label: 'Demo mode',
      description: 'Plays made-up traffic around your area. No CoreScope connection needed.'
    }
  }
  await DeskThing.initSettings(settings)
}

const readConfig = async (incoming?: any): Promise<Config> => {
  const s: any = incoming || (await DeskThing.getSettings()) || {}
  const v = (id: string, d: any) => (s[id] && s[id].value !== undefined && s[id].value !== null ? s[id].value : d)
  let url = String(v('server_url', cfg.serverUrl) || '').trim()
  if (url && !/^https?:\/\//i.test(url)) url = 'https://' + url
  return {
    serverUrl: url || 'https://corescope.chicagolandmesh.org',
    area: String(v('area', cfg.area) || '').trim(),
    radiusMi: Math.max(5, Math.min(500, num(v('radius_mi', cfg.radiusMi)) || 60)),
    watchRepeater: String(v('watch_repeater', '') || '').trim(),
    myNodesText: String(v('my_nodes', '') || ''),
    mapStyle: String(v('map_style', 'dark') || 'dark'),
    tileKey: String(v('map_key', '') || '').trim().replace(/[^A-Za-z0-9_\-.]/g, ''),
    showAcks: !!v('show_acks', false),
    demo: !!v('demo_mode', false),
    alertMyNodes: v('alert_my_nodes', true) !== false,
    quietMin: Math.max(5, num(v('alert_quiet_min', 60)) || 60),
    silentHours: Math.max(1, num(v('alert_silent_hours', 6)) || 6),
    keywords: String(v('alert_keywords', '') || '')
      .split(',')
      .map((k) => k.trim().toLowerCase())
      .filter((k) => k.length >= 2)
      .slice(0, 20),
    alertNewNodes: !!v('alert_new_nodes', false),
    ambientIdleMin: Math.max(0, Math.min(120, num(v('ambient_idle_min', 5)) ?? 5)),
    mentionNames: String(v('alert_mentions', '') || '')
      .split(',')
      .map((k) => k.trim())
      .filter((k) => k.length >= 2)
      .slice(0, 30),
    mentionMyNodes: v('alert_mention_my_nodes', true) !== false,
    dimMode: String(v('dim_mode', 'auto') || 'auto')
  }
}

// ============================================================
// AREA / REPEATER RESOLUTION
// ============================================================
const geocode = async (q: string): Promise<{ ll: LatLon; label: string } | null> => {
  const m = q.match(/^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$/)
  if (m) {
    const ll: LatLon = [parseFloat(m[1]), parseFloat(m[2])]
    if (validLL(ll[0], ll[1])) return { ll, label: `${ll[0].toFixed(3)}, ${ll[1].toFixed(3)}` }
  }
  const cacheKey = q.trim().toLowerCase()
  if (geoCache[cacheKey]) return geoCache[cacheKey]
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 8000)
  try {
    const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(q)
    const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json' }, signal: ctrl.signal })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    const arr: any = await res.json()
    if (Array.isArray(arr) && arr.length) {
      const lat = num(arr[0].lat)
      const lon = num(arr[0].lon)
      if (lat !== null && lon !== null) {
        const label = String(arr[0].display_name || q).split(',').slice(0, 2).join(',').trim()
        const hit = { ll: [lat, lon] as LatLon, label }
        geoCache[cacheKey] = hit
        persist()
        return hit
      }
    }
  } catch (e: any) {
    console.error(`${TAG} Area lookup failed for "${q}": ${e && e.name === 'AbortError' ? 'timed out' : e && e.message}. Tip: use "lat, lon" in the Area setting.`)
  } finally {
    clearTimeout(timer)
  }
  return null
}

const findNode = async (q: string): Promise<MeshNode | null> => {
  const needle = q.trim().toLowerCase()
  if (!needle) return null
  // Local first: exact name, then key prefix, then partial name
  let best: MeshNode | null = null
  for (const n of nodes.values()) {
    if (n.name.toLowerCase() === needle) return n
    if (!best && /^[0-9a-f]{2,}$/.test(needle) && n.key.startsWith(needle)) best = n
  }
  if (best) return best
  if (!cfg.demo) {
    try {
      const data = await apiGet('/api/nodes/search?q=' + encodeURIComponent(q))
      const list: any[] = (data && data.nodes) || []
      for (const raw of list) {
        const n = upsertNode(raw)
        if (n) return n
      }
    } catch (e) {
      console.error(`${TAG} node search failed`, e)
    }
  }
  for (const n of nodes.values()) if (n.name.toLowerCase().includes(needle)) return n
  return null
}

const resolveArea = async () => {
  repeaterKey = ''
  repeaterName = ''
  let gotCenter = false
  if (cfg.watchRepeater) {
    const n = await findNode(cfg.watchRepeater)
    if (n) {
      repeaterKey = n.key
      repeaterName = n.name
      if (n.lat !== null && n.lon !== null) {
        center = [n.lat, n.lon]
        areaLabel = n.name
        gotCenter = true
      }
      console.log(`${TAG} Watching repeater ${n.name} (${n.key.slice(0, 8)})`)
    } else {
      console.log(`${TAG} Repeater "${cfg.watchRepeater}" not found yet`)
    }
  }
  if (!gotCenter && cfg.area) {
    const g = await geocode(cfg.area)
    if (g) {
      center = g.ll
      areaLabel = g.label
    } else {
      areaLabel = cfg.area + ' (not found)'
    }
  }
}

// ============================================================
// NODE + OBSERVER DIRECTORY
// ============================================================
const upsertNode = (raw: any): MeshNode | null => {
  const key = String(raw.public_key || raw.pubKey || raw.pubkey || '').toLowerCase()
  if (!key) return null
  const prev = nodes.get(key)
  const lat = num(raw.lat)
  const lon = num(raw.lon)
  const n: MeshNode = {
    key,
    name: String(raw.name || (prev && prev.name) || key.slice(0, 8)),
    role: String(raw.role || (prev && prev.role) || 'unknown').toLowerCase(),
    lat: validLL(lat, lon) ? lat : prev ? prev.lat : null,
    lon: validLL(lat, lon) ? lon : prev ? prev.lon : null,
    last: Math.max(parseTime(raw.last_heard), parseTime(raw.last_seen), prev ? prev.last : 0)
  }
  nodes.set(key, n)
  return n
}

let nodesLoading = false
const doLoadNodes = async () => {
  if (cfg.demo || nodesLoading) return
  nodesLoading = true
  try {
    console.log(`${TAG} Loading node list from ${baseUrl()}`)
    let offset = 0
    let pages = 0
    let more = true
    while (more && pages < 20) {
      const data = await apiGet(`/api/nodes?limit=500&offset=${offset}`, 20000)
      const list: any[] = (data && data.nodes) || []
      list.forEach(upsertNode)
      console.log(`${TAG} Loading nodes... ${offset + list.length}${data && data.total ? ' of ' + data.total : ''}`)
      offset += list.length
      pages++
      more = !!(data && data.hasMore) && list.length > 0
    }
    try {
      const obs = await apiGet('/api/observers')
      const olist: any[] = (obs && obs.observers) || []
      olist.forEach((o) => {
        const id = String(o.id || '').toLowerCase()
        if (!id) return
        const lat = num(o.lat)
        const lon = num(o.lon)
        observers.set(id, {
          name: String(o.name || id.slice(0, 8)),
          lat: validLL(lat, lon) ? lat : null,
          lon: validLL(lat, lon) ? lon : null,
          iata: o.iata ? String(o.iata) : '',
          last: Math.max(parseTime(o.last_packet_at), parseTime(o.last_seen)),
          pkh: num(o.packetsLastHour) || 0,
          cnt: num(o.packet_count) || 0
        })
      })
    } catch (e) {
      console.error(`${TAG} observers load failed`, e)
    }
    console.log(`${TAG} Directory: ${nodes.size} nodes, ${observers.size} observers`)
    directoryReady = true
    sendObservers()
    if (cfg.watchRepeater && !repeaterKey) await resolveArea().then(sendConfig)
    resolveMyNodeKeys()
    sendNodes()
    loadMyNodes()
  } catch (e: any) {
    console.error(`${TAG} node load failed`, e)
    setStatus('error', 'Cannot reach CoreScope: ' + (e && e.message ? e.message : 'unknown error'))
  } finally {
    nodesLoading = false
  }
}
const loadNodes = () => {
  doLoadNodes()
}

const sendNodes = () => {
  const limit = cfg.radiusMi * 1.4
  const out: any[] = []
  for (const n of nodes.values()) {
    if (n.lat === null || n.lon === null) continue
    if (milesBetween(center, [n.lat, n.lon]) > limit) continue
    out.push({
      k: n.key,
      n: n.name,
      r: n.role,
      la: Math.round(n.lat * 1e5) / 1e5,
      lo: Math.round(n.lon * 1e5) / 1e5,
      m: myNodeKeys.indexOf(n.key) >= 0 ? 1 : 0,
      w: n.key === repeaterKey ? 1 : 0
    })
    if (out.length >= 900) break
  }
  send('nodes', out)
}

const sendConfig = () => {
  send('config', {
    center,
    radiusMi: cfg.radiusMi,
    areaLabel,
    repeaterName,
    mapStyle: cfg.mapStyle + '-' + tileSource(),
    showAcks: cfg.showAcks,
    darken: tileSource() === 'osm' && cfg.mapStyle === 'dark',
    attrib: tileSource() === 'carto' ? '© OpenStreetMap contributors · © CARTO' : tileSource() === 'osm' ? '© OpenStreetMap contributors' : '',
    demo: cfg.demo,
    version: APP_VERSION,
    ambientIdleMin: cfg.ambientIdleMin,
    dimMode: cfg.dimMode,
    server: baseUrl().replace(/^https?:\/\//, '')
  })
}

// ============================================================
// HOP RESOLUTION
// ============================================================
const nodeByPrefix = (prefix: string, near: LatLon | null): MeshNode | null => {
  const p = prefix.toLowerCase()
  let best: MeshNode | null = null
  let bestD = Infinity
  let count = 0
  for (const n of nodes.values()) {
    if (!n.key.startsWith(p) || n.lat === null || n.lon === null) continue
    count++
    const d = milesBetween(near || center, [n.lat, n.lon])
    if (d < bestD) {
      bestD = d
      best = n
    }
  }
  if (!best) return null
  // 1-byte prefixes collide a lot: only accept a nearby, plausible match
  if (p.length <= 2 && count > 1 && bestD > 40) return null
  if (bestD > 250) return null
  return best
}

interface Pt {
  ll: LatLon
  key: string
}

const buildPath = (pkt: any, payload: any, hops: string[]): Pt[] => {
  const pts: Pt[] = []
  const push = (ll: LatLon, key: string) => {
    const last = pts[pts.length - 1]
    if (last && (last.key === key || (last.ll[0] === ll[0] && last.ll[1] === ll[1]))) return
    // A single LoRa hop longer than this is a bad match (or an internet bridge): skip it
    if (last && milesBetween(last.ll, ll) > MAX_HOP_MILES) return
    pts.push({ ll, key })
  }
  // Sender (adverts carry their own position)
  const senderKey = String(payload.pubKey || payload.srcPubKey || '').toLowerCase()
  if (senderKey) {
    if (validLL(payload.lat, payload.lon)) push([num(payload.lat)!, num(payload.lon)!], senderKey)
    else {
      const sn = nodes.get(senderKey)
      if (sn && sn.lat !== null && sn.lon !== null) push([sn.lat, sn.lon], senderKey)
    }
  }
  // Relay hops
  let resolved: any = parseMaybeJSON(pkt.resolved_path)
  if (!Array.isArray(resolved) || resolved.length !== hops.length) resolved = null
  hops.forEach((h, i) => {
    let n: MeshNode | null = null
    const rk = resolved && resolved[i] ? String(resolved[i]).toLowerCase() : ''
    if (rk) n = nodes.get(rk) || null
    if (!n) n = nodeByPrefix(String(h), pts.length ? pts[pts.length - 1].ll : null)
    if (n && n.lat !== null && n.lon !== null) push([n.lat, n.lon], n.key)
  })
  // Receiving observer is the end of the streak
  const oid = String(pkt.observer_id || '').toLowerCase()
  if (oid) {
    const o = observers.get(oid)
    const on = nodes.get(oid)
    if (o && o.lat !== null && o.lon !== null) push([o.lat, o.lon], oid)
    else if (on && on.lat !== null && on.lon !== null) push([on.lat, on.lon], oid)
  }
  return pts
}

// ============================================================
// PACKET HANDLING
// ============================================================
const handlePacket = (pkt: any) => {
  if (!pkt) return
  pktTimes.push(Date.now())
  const decoded = pkt.decoded || {}
  const header = decoded.header || {}
  const typeName: string = String(header.payloadTypeName || 'UNKNOWN')
  const payload: any = decoded.payload || parseMaybeJSON(pkt.decoded_json) || {}

  if (typeName === 'ADVERT' && payload.pubKey) {
    const isNew = directoryReady && !nodes.has(String(payload.pubKey).toLowerCase())
    const n = upsertNode({ public_key: payload.pubKey, name: payload.name, lat: payload.lat, lon: payload.lon })
    if (n) n.last = Date.now()
    if (isNew && n && cfg.alertNewNodes && n.lat !== null && n.lon !== null) {
      const d = milesBetween(center, [n.lat, n.lon])
      if (d <= cfg.radiusMi) raiseAlert('newnode', 'new:' + n.key, 'New node: ' + n.name, (n.role !== 'unknown' ? n.role + ' · ' : '') + d.toFixed(1) + ' mi from center', { k: n.key, la: n.lat, lo: n.lon })
    }
  }
  if (typeName === 'GRP_TXT' && payload.text) {
    checkKeywords(String(payload.channel || ''), String(payload.sender || ''), String(payload.text))
    checkMentions(String(payload.channel || ''), String(payload.sender || ''), String(payload.text))
  }
  if (typeName === 'GRP_TXT' && payload.channel && payload.text) {
    let hopCount = 0
    const hp = parseMaybeJSON(pkt.path_json)
    if (Array.isArray(hp)) hopCount = hp.length
    send('chanmsg', {
      ch: String(payload.channel),
      id: String(pkt.hash || ''),
      who: String(payload.sender || 'unknown').slice(0, 30),
      text: String(payload.text).slice(0, 300),
      ts: Date.now(),
      obs: pkt.observer_name ? String(pkt.observer_name).slice(0, 30) : '',
      hops: hopCount,
      snr: num(pkt.snr)
    })
  }
  const info0 = TYPE_INFO[typeName] || { label: typeName.slice(0, 7), color: '#C9A0FF' }
  const group = groupOf(info0.label)
  if (clientGroups) {
    if (clientGroups.indexOf(group) < 0) return
  } else if (!cfg.showAcks && group === 'CONTROL') return

  let hops: any = parseMaybeJSON(pkt.path_json)
  if (!Array.isArray(hops)) hops = (decoded.path && decoded.path.hops) || []
  hops = hops.map((h: any) => (typeof h === 'string' ? h : h && (h.prefix || h.id) ? String(h.prefix || h.id) : '')).filter((h: string) => h)

  const pts = buildPath(pkt, payload, hops)
  if (myNodeKeys.length) {
    const sk = String(payload.pubKey || payload.srcPubKey || '').toLowerCase()
    if (sk) noteHeard(sk)
    pts.forEach((p) => noteHeard(p.key))
  }
  if (!pts.length) return

  // Filters
  if (repeaterKey) {
    const through = pts.some((p) => p.key === repeaterKey) || hops.some((h: string) => repeaterKey.startsWith(h.toLowerCase()) && h.length >= 4)
    if (!through) return
  } else {
    const inArea = pts.some((p) => milesBetween(center, p.ll) <= cfg.radiusMi)
    if (!inArea) return
  }

  // Same transmission is heard by many observers; keep a few distinct paths
  const hash = String(pkt.hash || '')
  const pathKey = hash + '|' + pts.map((p) => p.key.slice(0, 6)).join('>')
  const now = Date.now()
  if (recentHashes.has(pathKey)) return
  recentHashes.set(pathKey, now)
  if (recentHashes.size > 3000) {
    for (const [k, t] of recentHashes) if (now - t > 60000) recentHashes.delete(k)
  }
  let seenForHash = 0
  if (hash) for (const k of recentHashes.keys()) if (k.startsWith(hash + '|')) seenForHash++
  const firstForHash = seenForHash <= 1
  if (seenForHash > 6) return

  if (routeBudget <= 0) return
  routeBudget--

  const info = TYPE_INFO[typeName] || { label: typeName.slice(0, 7), color: '#C9A0FF' }
  const senderKey = String(payload.pubKey || payload.srcPubKey || '').toLowerCase()
  const sender = senderKey ? nodes.get(senderKey) : undefined
  let who = payload.name || (sender && sender.name) || ''
  let text = ''
  if (typeName === 'GRP_TXT') {
    who = payload.sender || who || payload.channel || 'channel'
    if (payload.text) text = String(payload.text).slice(0, 90)
    if (payload.channel) text = (payload.channel.charAt(0) === '#' ? '' : '#') + payload.channel + (text ? ': ' + text : '')
  }
  if (!who) who = pts[0].key ? (nodes.get(pts[0].key) || { name: pts[0].key.slice(0, 8) }).name : 'unknown'

  const mineInvolved = pts.some((p) => myNodeKeys.indexOf(p.key) >= 0)
  routesSent++
  send('route', {
    g: group,
    t: info.label,
    c: info.color,
    p: pts.map((p) => [Math.round(p.ll[0] * 1e5) / 1e5, Math.round(p.ll[1] * 1e5) / 1e5]),
    who: String(who).slice(0, 40),
    txt: text,
    k: senderKey,
    h: hops.length,
    snr: num(pkt.snr),
    obs: String(pkt.observer_name || '').slice(0, 30),
    feed: firstForHash,
    mine: mineInvolved,
    ts: now
  })
}

// ============================================================
// WEBSOCKET
// ============================================================
const wsUrl = (): string => baseUrl().replace(/^http/i, 'ws') + '/ws'

const connectWS = () => {
  if (!running || cfg.demo) return
  if (wsTimer) {
    clearTimeout(wsTimer)
    wsTimer = null
  }
  dropWS()
  const url = wsUrl()
  console.log(`${TAG} Connecting ${url}`)
  setStatus('connecting', 'Connecting to ' + baseUrl().replace(/^https?:\/\//, ''))
  let sock: WebSocket
  try {
    sock = new WebSocket(url, { headers: { 'User-Agent': UA }, handshakeTimeout: 15000 })
  } catch (e) {
    console.error(`${TAG} WS create failed`, e)
    scheduleReconnect()
    return
  }
  ws = sock
  wsLastMsg = Date.now()
  sock.on('open', () => {
    console.log(`${TAG} Connected to live feed (${url})`)
    firstPacketLogged = false
    wsBackoff = 2000
    setStatus('live', 'Live from ' + baseUrl().replace(/^https?:\/\//, ''))
  })
  sock.on('message', (data: WebSocket.RawData) => {
    wsLastMsg = Date.now()
    const textData = data.toString()
    if (textData === '{"type":"heartbeat"}') return
    try {
      const msg = JSON.parse(textData)
      if (msg && msg.type === 'packet') {
        if (!firstPacketLogged) {
          firstPacketLogged = true
          console.log(`${TAG} Receiving packets`)
        }
        livePackets++
        handlePacket(msg.data)
      }
    } catch {
      /* ignore malformed */
    }
  })
  sock.on('error', (e: any) => {
    console.error(`${TAG} WS error: ${e && e.message ? e.message : e}`)
  })
  sock.on('close', (code: number) => {
    console.log(`${TAG} Live feed closed (code ${code})`)
    if (ws === sock) {
      ws = null
      if (running && !cfg.demo) {
        setStatus('connecting', 'Reconnecting...')
        scheduleReconnect()
      }
    }
  })
}

const dropWS = () => {
  if (ws) {
    const s = ws
    ws = null
    try {
      s.removeAllListeners()
      s.on('error', () => {})
      s.terminate()
    } catch {
      /* ignore */
    }
  }
}

const scheduleReconnect = () => {
  if (wsTimer || !running) return
  wsTimer = setTimeout(() => {
    wsTimer = null
    connectWS()
  }, wsBackoff)
  wsBackoff = Math.min(60000, wsBackoff * 2)
}

const checkWS = () => {
  if (!running || cfg.demo) return
  if (ws && Date.now() - wsLastMsg > 90000) {
    console.log(`${TAG} No data for 90s, reconnecting`)
    connectWS()
  }
}

// ============================================================
// CHANNELS + OBSERVERS
// ============================================================
let channelList: any[] = []

const sendObservers = () => {
  const out: any[] = []
  for (const o of observers.values()) {
    out.push({ n: o.name, iata: o.iata || '', last: o.last || 0, pkh: o.pkh || 0, cnt: o.cnt || 0 })
  }
  out.sort((a, b) => b.last - a.last)
  send('observers', out.slice(0, 60))
}

const doLoadChannels = async () => {
  if (cfg.demo) {
    channelList = [
      { h: '#demo', n: '#demo', last: 'Good signal here', who: 'Demo-3', cnt: 128, ts: Date.now() - 60000 },
      { h: 'Public', n: 'Public', last: 'Anyone on?', who: 'Demo-7', cnt: 2045, ts: Date.now() - 300000 },
      { h: '#test', n: '#test', last: 'test 1 2 3', who: 'Demo-1', cnt: 77, ts: Date.now() - 3600e3 }
    ]
    send('channels', channelList)
    return
  }
  try {
    const data = await apiGet('/api/channels')
    const list: any[] = (data && data.channels) || []
    channelList = list
      .map((c) => ({
        h: String(c.hash || c.name || ''),
        n: String(c.name || c.hash || '?'),
        last: c.lastMessage ? String(c.lastMessage).slice(0, 80) : '',
        who: c.lastSender ? String(c.lastSender).slice(0, 30) : '',
        cnt: num(c.messageCount) || 0,
        ts: parseTime(c.lastActivity)
      }))
      .filter((c) => c.h)
      .sort((a, b) => b.ts - a.ts)
      .slice(0, 40)
    send('channels', channelList)
  } catch (e: any) {
    console.error(`${TAG} channels load failed: ${e && e.message}`)
  }
}
const loadChannels = () => {
  doLoadChannels()
}

const mapMessage = (m: any) => ({
  id: String(m.packetHash || m.packetId || m.timestamp || Math.random()),
  who: String(m.sender || 'unknown').slice(0, 30),
  text: String(m.text || '').slice(0, 300),
  ts: parseTime(m.timestamp || m.first_seen),
  rep: num(m.repeats) || 1,
  obs: Array.isArray(m.observers) ? m.observers.map((o: any) => String(o).slice(0, 30)).slice(0, 12) : [],
  hops: num(m.hops),
  snr: num(m.snr)
})

const doGetMessages = async (data: any) => {
  const h = String((data && data.payload && data.payload.h) || '')
  if (!h) return
  if (cfg.demo) {
    const now = Date.now()
    const list = ['Anyone on?', 'Copy, good signal here', 'Testing from the car', '73 all', 'Heard you 3 hops out'].map((t, i) => ({
      id: 'demo' + i, who: 'Demo-' + (i + 2), text: t, ts: now - (5 - i) * 240000, rep: 1 + i, obs: ['Observer'], hops: i % 4, snr: 4 - i
    }))
    send('messages', { h, list })
    return
  }
  try {
    const res = await apiGet('/api/channels/' + encodeURIComponent(h) + '/messages?limit=60')
    const list = ((res && res.messages) || []).map(mapMessage).sort((a: any, b: any) => a.ts - b.ts)
    send('messages', { h, list })
  } catch (e: any) {
    console.error(`${TAG} messages for ${h} failed: ${e && e.message}`)
    send('messages', { h, list: [], error: 'Could not load messages' })
  }
}
const getMessages = (data: any) => {
  doGetMessages(data)
}

// ============================================================
// ALERTS
// ============================================================
const myLastHeard = new Map<string, number>() // key -> ms
const silentAlerted = new Set<string>()
const alertCooldown = new Map<string, number>()
let directoryReady = false
let alertSeq = 0
let alertTimer: ReturnType<typeof setInterval> | null = null

const raiseAlert = (kind: string, dedupeKey: string, title: string, body: string, extra: any = {}) => {
  const now = Date.now()
  const last = alertCooldown.get(dedupeKey) || 0
  if (now - last < 60000) return
  alertCooldown.set(dedupeKey, now)
  if (alertCooldown.size > 500) for (const [k, t] of alertCooldown) if (now - t > 3600e3) alertCooldown.delete(k)
  const colors: Record<string, string> = { back: '#3DDC97', silent: '#FF7A59', keyword: '#39D0FF', newnode: '#FFB547', mention: '#F472B6' }
  console.log(`${TAG} ALERT ${title}: ${body}`)
  send('alert', { id: ++alertSeq, kind, title, body: body.slice(0, 160), color: colors[kind] || '#E6EDF3', ts: now, ...extra })
}

const fmtDur = (ms: number): string => {
  const m = Math.round(ms / 60000)
  if (m < 60) return m + ' min'
  const h = Math.floor(m / 60)
  if (h < 48) return h + 'h' + (m % 60 ? ' ' + (m % 60) + 'm' : '')
  return Math.round(h / 24) + ' days'
}

// Called for every node seen in a packet (sender, relays, observer)
const noteHeard = (key: string) => {
  if (myNodeKeys.indexOf(key) < 0) return
  const now = Date.now()
  const prev = myLastHeard.get(key) || 0
  myLastHeard.set(key, now)
  silentAlerted.delete(key)
  if (!cfg.alertMyNodes || !prev) return
  const gap = now - prev
  if (gap >= cfg.quietMin * 60000) {
    const n = nodes.get(key)
    raiseAlert('back', 'back:' + key, (n ? n.name : key.slice(0, 8)) + ' is back on the air', 'Quiet for ' + fmtDur(gap), {
      k: key,
      la: n ? n.lat : null,
      lo: n ? n.lon : null
    })
  }
}

const checkSilent = () => {
  if (!running || !cfg.alertMyNodes) return
  const now = Date.now()
  for (const key of myNodeKeys) {
    const last = myLastHeard.get(key) || 0
    if (!last || silentAlerted.has(key)) continue
    if (now - last >= cfg.silentHours * 3600e3) {
      silentAlerted.add(key)
      const n = nodes.get(key)
      raiseAlert('silent', 'silent:' + key, (n ? n.name : key.slice(0, 8)) + ' has gone silent', 'Not heard for ' + fmtDur(now - last), {
        k: key,
        la: n ? n.lat : null,
        lo: n ? n.lon : null
      })
    }
  }
}

const checkKeywords = (channel: string, sender: string, text: string) => {
  if (!cfg.keywords.length) return
  const hay = (sender + ' ' + text).toLowerCase()
  const hit = cfg.keywords.find((k) => hay.indexOf(k) >= 0)
  if (!hit) return
  raiseAlert('keyword', 'kw:' + channel + ':' + sender + ':' + text.slice(0, 40), (channel || 'Channel') + ': "' + hit + '"', (sender ? sender + ': ' : '') + text, {
    ch: channel
  })
}

// ---------- @mentions ----------
const escRe = (t: string) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

// Every name we watch for, with the key when we know it (names can change; keys don't)
const mentionTargets = (): { name: string; key: string }[] => {
  const out: { name: string; key: string }[] = []
  const seen = new Set<string>()
  const add = (name: string, key: string) => {
    const nm = (key && nodes.get(key) ? nodes.get(key)!.name : name || '').trim()
    if (nm.length < 2 || seen.has(nm.toLowerCase())) return
    seen.add(nm.toLowerCase())
    out.push({ name: nm, key })
  }
  savedMentions.forEach((m) => add(m.name, m.key))
  cfg.mentionNames.forEach((n) => add(n, ''))
  if (cfg.mentionMyNodes) myNodeKeys.forEach((k) => add((nodes.get(k) || { name: '' }).name, k))
  return out
}

const mentionMatch = (text: string, name: string): boolean => {
  const n = escRe(name)
  // MeshCore app style @[Name], or plain @Name followed by a non-name character
  return new RegExp('@\\[\\s*' + n + '\\s*\\]', 'i').test(text) || new RegExp('@' + n + '(?![A-Za-z0-9_-])', 'i').test(text)
}

const checkMentions = (channel: string, sender: string, text: string) => {
  if (text.indexOf('@') < 0) return
  const targets = mentionTargets()
  for (const t of targets) {
    if (!mentionMatch(text, t.name)) continue
    const n = t.key ? nodes.get(t.key) : undefined
    raiseAlert('mention', 'mention:' + t.name + ':' + sender + ':' + text.slice(0, 40), '@' + t.name + ' mentioned in ' + (channel || 'a channel'), (sender ? sender + ': ' : '') + text, {
      ch: channel,
      k: t.key || '',
      la: n ? n.lat : null,
      lo: n ? n.lon : null,
      openChannel: true
    })
  }
}

const sendMentions = () => {
  send(
    'mentions',
    mentionTargets().map((t) => ({ k: t.key, n: t.name, src: savedMentions.some((m) => (t.key && m.key === t.key) || m.name.toLowerCase() === t.name.toLowerCase()) ? 'picked' : cfg.mentionNames.some((x) => x.toLowerCase() === t.name.toLowerCase()) ? 'settings' : 'mynode' }))
  )
}

const setMention = (data: any) => {
  const p = (data && data.payload) || {}
  const key = String(p.k || '').toLowerCase()
  const name = String(p.n || '').trim().slice(0, 40)
  if (!key && !name) return
  const idx = savedMentions.findIndex((m) => (key && m.key === key) || (!key && m.name.toLowerCase() === name.toLowerCase()))
  const want = p.on !== false
  if (want && idx < 0) savedMentions.push({ key, name })
  else if (!want && idx >= 0) savedMentions.splice(idx, 1)
  else return sendMentions()
  console.log(`${TAG} Mentions: ${want ? 'watching' : 'stopped watching'} @${name || key.slice(0, 8)}`)
  persist()
  sendMentions()
}

// Search nodes by name or key prefix for the Find node screen
const doFindNodes = async (data: any) => {
  const q = String((data && data.payload && data.payload.q) || '').trim()
  const ql = q.toLowerCase()
  const results: MeshNode[] = []
  const seen = new Set<string>()
  const push = (n: MeshNode) => {
    if (seen.has(n.key) || results.length >= 40) return
    seen.add(n.key)
    results.push(n)
  }
  if (ql.length >= 1) {
    const all = Array.from(nodes.values())
    // starts-with matches first, then contains, then key prefix
    all.filter((n) => n.name.toLowerCase().startsWith(ql)).forEach(push)
    all.filter((n) => n.name.toLowerCase().includes(ql)).forEach(push)
    if (/^[0-9a-f]{2,}$/.test(ql)) all.filter((n) => n.key.startsWith(ql)).forEach(push)
    if (results.length < 10 && ql.length >= 2 && !cfg.demo) {
      try {
        const res = await apiGet('/api/nodes/search?q=' + encodeURIComponent(q), 8000)
        ;((res && res.nodes) || []).forEach((raw: any) => {
          const n = upsertNode(raw)
          if (n) push(n)
        })
      } catch (e: any) {
        console.error(`${TAG} node search failed: ${e && e.message}`)
      }
    }
  }
  const watched = mentionTargets()
  send('found', {
    q,
    list: results.map((n) => ({
      k: n.key,
      n: n.name,
      r: n.role,
      la: n.lat,
      lo: n.lon,
      last: n.last,
      mine: myNodeKeys.indexOf(n.key) >= 0,
      watch: watched.some((t) => (t.key && t.key === n.key) || t.name.toLowerCase() === n.name.toLowerCase())
    }))
  })
}
const findNodes = (data: any) => {
  doFindNodes(data)
}

// ============================================================
// MY NODES
// ============================================================
const resolveMyNodeKeys = () => {
  const keys: string[] = savedMyNodes.map((m) => m.key)
  cfg.myNodesText
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s)
    .forEach((entry) => {
      const e = entry.toLowerCase()
      let hit: MeshNode | null = null
      for (const n of nodes.values()) {
        if (n.name.toLowerCase() === e || (/^[0-9a-f]{4,}$/.test(e) && n.key.startsWith(e))) {
          hit = n
          break
        }
      }
      if (hit && keys.indexOf(hit.key) < 0) keys.push(hit.key)
    })
  myNodeKeys = keys
}

const healthStatus = (lastMs: number): string => {
  if (!lastMs) return 'silent'
  const age = Date.now() - lastMs
  if (age < 2 * 3600e3) return 'active'
  if (age < 24 * 3600e3) return 'degraded'
  return 'silent'
}

const doLoadMyNodes = async () => {
  resolveMyNodeKeys()
  const cards: any[] = []
  for (const key of myNodeKeys) {
    const n = nodes.get(key)
    const card: any = {
      k: key,
      n: n ? n.name : (savedMyNodes.find((m) => m.key === key) || { name: key.slice(0, 8) }).name,
      r: n ? n.role : 'unknown',
      last: n ? n.last : 0,
      snr: null,
      today: null,
      obs: null,
      la: n ? n.lat : null,
      lo: n ? n.lon : null
    }
    if (!cfg.demo) {
      try {
        const h = await apiGet('/api/nodes/' + encodeURIComponent(key) + '/health')
        const hn = (h && h.node) || {}
        const st = (h && h.stats) || {}
        if (hn.name) card.n = String(hn.name)
        if (hn.role) card.r = String(hn.role).toLowerCase()
        card.last = Math.max(card.last, parseTime(st.lastHeard), parseTime(hn.last_seen))
        card.snr = num(st.avgSnr)
        card.today = num(st.packetsToday)
        card.obs = Array.isArray(h && h.observers) ? h.observers.length : null
        if (validLL(hn.lat, hn.lon)) {
          card.la = num(hn.lat)
          card.lo = num(hn.lon)
        }
      } catch (e: any) {
        console.error(`${TAG} health for ${key.slice(0, 8)} failed: ${e && e.message}`)
      }
    } else {
      card.snr = Math.round((Math.random() * 16 - 4) * 4) / 4
      card.today = Math.floor(Math.random() * 300)
      card.obs = 1 + Math.floor(Math.random() * 6)
      card.last = Date.now() - Math.floor(Math.random() * 5 * 3600e3)
    }
    card.status = healthStatus(card.last)
    if (card.last && (myLastHeard.get(key) || 0) < card.last) myLastHeard.set(key, card.last)
    cards.push(card)
  }
  myNodeCards = cards
  send('mynodes', cards)
  sendMentions()
}
const loadMyNodes = () => {
  doLoadMyNodes()
}

const toggleMyNode = (data: any) => {
  const p = (data && data.payload) || {}
  const key = String(p.k || '').toLowerCase()
  if (!key) return
  const idx = savedMyNodes.findIndex((m) => m.key === key)
  // Explicit add/remove ("on"), so a repeated message can never undo itself.
  // Older clients send no "on": treat that as a toggle.
  const want = typeof p.on === 'boolean' ? p.on : idx < 0
  if (want && idx < 0) savedMyNodes.push({ key, name: String(p.n || key.slice(0, 8)).slice(0, 40) })
  else if (!want && idx >= 0) savedMyNodes.splice(idx, 1)
  else return
  console.log(`${TAG} My Nodes: ${want ? 'added' : 'removed'} ${p.n || key.slice(0, 8)} (${savedMyNodes.length} saved)`)
  persist()
  resolveMyNodeKeys()
  sendNodes()
  loadMyNodes()
}

const loadSavedMyNodes = async () => {
  try {
    const d: any = await DeskThing.getData()
    const list = d && Array.isArray(d.myNodes) ? d.myNodes : []
    savedMyNodes = list
      .filter((m: any) => m && m.key)
      .map((m: any) => ({ key: String(m.key).toLowerCase(), name: String(m.name || '') }))
    if (d && d.geoCache && typeof d.geoCache === 'object') geoCache = d.geoCache
    if (d && Array.isArray(d.mentions))
      savedMentions = d.mentions
        .filter((m: any) => m && (m.key || m.name))
        .map((m: any) => ({ key: String(m.key || '').toLowerCase(), name: String(m.name || '').slice(0, 40) }))
  } catch (e) {
    console.error(`${TAG} getData failed`, e)
  }
}

// ============================================================
// MAP TILES (the Car Thing cannot reach the internet, so tiles come from here)
// ============================================================
const fetchTile = async (z: number, x: number, y: number) => {
  const src = tileSource()
  if (src === 'none') return
  const styleTag = cfg.mapStyle + '-' + src
  const key = `${styleTag}/${z}/${x}/${y}`
  const cached = tileCache.get(key)
  if (cached) {
    send('tile', { z, x, y, style: styleTag, d: cached })
    return
  }
  if (tilePending.has(key)) return
  tilePending.add(key)
  try {
    const tmpl = src === 'carto' ? CARTO_URLS[cfg.mapStyle] || CARTO_URLS.dark : OSM_URL
    const url = tmpl.replace('{key}', encodeURIComponent(cfg.tileKey)).replace('{z}', String(z)).replace('{x}', String(x)).replace('{y}', String(y))
    const res = await fetch(url, { headers: { 'User-Agent': UA, Referer: 'https://github.com/HamRadioDude/HamThing' } })
    if (!res.ok) {
      if (res.status === 401 || res.status === 403) setStatus(status.conn, src === 'carto' ? 'Map key rejected by CARTO - check the key or clear it to use OpenStreetMap' : 'Map tiles refused (HTTP ' + res.status + ')')
      throw new Error('HTTP ' + res.status)
    }
    const type = res.headers.get('content-type') || 'image/png'
    const buf = Buffer.from(await res.arrayBuffer())
    const dataUrl = 'data:' + (type.indexOf('image/') === 0 ? type : 'image/png') + ';base64,' + buf.toString('base64')
    tileCache.set(key, dataUrl)
    if (tileCache.size > TILE_CACHE_MAX) {
      const first = tileCache.keys().next().value
      if (first) tileCache.delete(first)
    }
    send('tile', { z, x, y, style: styleTag, d: dataUrl })
  } catch (e: any) {
    console.error(`${TAG} tile ${key} failed: ${e && e.message}`)
  } finally {
    tilePending.delete(key)
  }
}

const doGetTiles = async (data: any) => {
  const list: any[] = (data && data.payload && data.payload.tiles) || []
  const max = 1 << 18
  const queue = list
    .slice(0, 40)
    .filter((t) => t && Number.isInteger(t.z) && t.z >= 2 && t.z <= 17 && Number.isInteger(t.x) && Number.isInteger(t.y) && t.x >= 0 && t.y >= 0 && t.x < max && t.y < max)
  const workers = (tileSource() === 'osm' ? [0, 1] : [0, 1, 2, 3]).map(async () => {
    while (queue.length) {
      const t = queue.shift()
      if (t) await fetchTile(t.z, t.x, t.y)
    }
  })
  await Promise.all(workers)
}
const getTiles = (data: any) => {
  doGetTiles(data)
}

// ============================================================
// DEMO MODE
// ============================================================
const DEMO_NAMES = ['Ridge', 'Harbor', 'Mill', 'Prairie', 'Tower', 'Creek', 'Summit', 'Depot', 'Grove', 'Bluff', 'Lakeside', 'Junction']

const seedDemoNodes = () => {
  nodes.clear()
  observers.clear()
  const spread = Math.min(cfg.radiusMi, 60) / 69 // degrees of latitude
  const lonScale = 1 / Math.max(0.2, Math.cos((center[0] * Math.PI) / 180))
  const rnd = (s: number) => (Math.random() * 2 - 1) * s
  for (let i = 0; i < 12; i++) {
    const key = ('d' + i.toString(16).padStart(2, '0') + 'demo').padEnd(64, '0')
    upsertNode({ public_key: key, name: DEMO_NAMES[i] + '-RPT', role: 'repeater', lat: center[0] + rnd(spread * 0.8), lon: center[1] + rnd(spread * 0.8 * lonScale) })
  }
  for (let i = 0; i < 26; i++) {
    const key = ('c' + i.toString(16).padStart(2, '0') + 'demo').padEnd(64, '0')
    upsertNode({ public_key: key, name: 'Demo-' + (i + 1), role: 'companion', lat: center[0] + rnd(spread), lon: center[1] + rnd(spread * lonScale) })
  }
  const obsKey = 'ob00demo'.padEnd(64, '0')
  upsertNode({ public_key: obsKey, name: 'Observer', role: 'observer', lat: center[0], lon: center[1] })
  observers.set(obsKey, { name: 'Observer', lat: center[0], lon: center[1], iata: 'DEMO', last: Date.now(), pkh: 240, cnt: 51234 })
}

const demoTick = () => {
  if (!running || !cfg.demo) return
  const all = Array.from(nodes.values())
  const rpts = all.filter((n) => n.role === 'repeater')
  const comps = all.filter((n) => n.role === 'companion')
  const types = ['ADVERT', 'GRP_TXT', 'GRP_TXT', 'TXT_MSG', 'TRACE', 'PATH']
  const t = types[Math.floor(Math.random() * types.length)]
  const src = (t === 'ADVERT' && Math.random() < 0.5 ? rpts : comps)[Math.floor(Math.random() * (t === 'ADVERT' ? rpts.length : comps.length))] || all[0]
  // Walk toward the observer through nearby repeaters
  const obs = observers.keys().next().value as string
  const hopsN = 1 + Math.floor(Math.random() * 4)
  const hops: string[] = []
  let cur: LatLon = [src.lat!, src.lon!]
  const used = new Set<string>()
  for (let i = 0; i < hopsN; i++) {
    const cands = rpts.filter((r) => !used.has(r.key)).sort((a, b) => milesBetween(cur, [a.lat!, a.lon!]) - milesBetween(cur, [b.lat!, b.lon!]))
    const pick = cands[Math.floor(Math.random() * Math.min(3, cands.length))]
    if (!pick) break
    used.add(pick.key)
    hops.push(pick.key.slice(0, 4))
    cur = [pick.lat!, pick.lon!]
  }
  const pkt: any = {
    hash: Math.random().toString(16).slice(2),
    observer_id: obs,
    observer_name: 'Observer',
    snr: Math.round((Math.random() * 18 - 6) * 4) / 4,
    path_json: JSON.stringify(hops),
    decoded: {
      header: { payloadTypeName: t },
      payload:
        t === 'GRP_TXT'
          ? { channel: '#demo', sender: src.name, text: ['Anyone on?', 'Copy that', 'Testing from the car', 'Good signal here', '73'][Math.floor(Math.random() * 5)], pubKey: src.key }
          : { pubKey: src.key, name: src.name }
    }
  }
  handlePacket(pkt)
  demoTimer = setTimeout(demoTick, 350 + Math.random() * 1400)
}

// ============================================================
// APPLY CONFIG (start + settings changes)
// ============================================================
let applied = false
let lastAreaKey = ''

const doApply = async (incoming?: any) => {
  const prevStyle = cfg.mapStyle + cfg.tileKey
  const prevServer = cfg.serverUrl
  const prevDemo = cfg.demo
  cfg = await readConfig(incoming)
  const areaKey = [cfg.area, cfg.watchRepeater, cfg.radiusMi].join('|')
  const first = !applied
  applied = true
  if (prevStyle !== cfg.mapStyle + cfg.tileKey) tileCache.clear()
  if (prevServer !== cfg.serverUrl) {
    nodes.clear()
    observers.clear()
  }
  if (demoTimer) {
    clearTimeout(demoTimer)
    demoTimer = null
  }
  if (cfg.demo) {
    dropWS()
    lastAreaKey = areaKey
    await resolveArea()
    seedDemoNodes()
    setStatus('demo', 'Demo mode - made-up traffic')
    sendConfig()
    resolveMyNodeKeys()
    sendNodes()
    loadMyNodes()
    loadChannels()
    sendObservers()
    demoTick()
    return
  }
  if (nodes.size && nodes.keys().next().value!.indexOf('demo') > 0) nodes.clear()
  const serverChanged = first || prevDemo || prevServer !== cfg.serverUrl
  // Live feed and node list never wait on the area lookup
  if (serverChanged || !ws) connectWS()
  if (serverChanged || nodes.size === 0) {
    loadNodes()
    loadChannels()
  }
  if (serverChanged || areaKey !== lastAreaKey) {
    lastAreaKey = areaKey
    await resolveArea()
    console.log(`${TAG} Watching: ${repeaterName ? 'repeater ' + repeaterName : areaLabel} (${center[0].toFixed(3)}, ${center[1].toFixed(3)}), ${cfg.radiusMi} mi`)
  }
  sendConfig()
  resolveMyNodeKeys()
  sendNodes()
  loadMyNodes()
}
// Only one apply runs at a time (DeskThing fires a settings event during startup)
let applyChain: Promise<void> = Promise.resolve()
const applyNow = (incoming?: any): Promise<void> => {
  applyChain = applyChain.then(() => doApply(incoming)).catch((e) => console.error(`${TAG} apply failed`, e))
  return applyChain
}
const apply = (incoming?: any) => {
  if (settingsDebounce) clearTimeout(settingsDebounce)
  settingsDebounce = setTimeout(() => {
    settingsDebounce = null
    applyNow(incoming)
  }, 400)
}

const sendAll = () => {
  sendConfig()
  sendNodes()
  sendStatus()
  send('mynodes', myNodeCards)
  if (channelList.length) send('channels', channelList)
  sendObservers()
  sendMentions()
}

// ============================================================
// ACTIONS (map Car Thing buttons in DeskThing > Mappings)
// ============================================================
const ACTIONS = [
  { id: 'screenMap', name: 'Map Screen', description: 'Show the live map' },
  { id: 'screenFeed', name: 'Feed Screen', description: 'Show the packet feed' },
  { id: 'screenChannels', name: 'Channels Screen', description: 'Show channels and messages' },
  { id: 'screenMyNodes', name: 'My Nodes Screen', description: 'Show your saved nodes' },
  { id: 'screenStatus', name: 'Status Screen', description: 'Show connection status' },
  { id: 'nextScreen', name: 'Next Screen', description: 'Cycle screens' },
  { id: 'zoomIn', name: 'Zoom In', description: 'Zoom the map in' },
  { id: 'zoomOut', name: 'Zoom Out', description: 'Zoom the map out' },
  { id: 'recenter', name: 'Recenter', description: 'Recenter the map on your area' },
  { id: 'togglePause', name: 'Pause / Resume', description: 'Freeze or resume the live view' },
  { id: 'toggleAmbient', name: 'Ambient Mode', description: 'Full-screen map on or off' }
]

const initializeActions = async () => {
  for (const a of ACTIONS) {
    try {
      await DeskThing.registerAction({ ...a, tag: 'nav', version: '1.0.0', version_code: 1, enabled: true } as any)
    } catch (e: any) {
      console.log(`${TAG} action ${a.id}: ${e && e.message}`)
    }
  }
}

// ============================================================
// LIFECYCLE
// ============================================================
const start = async () => {
  console.log(`${TAG} Starting v${APP_VERSION}`)
  running = true
  lastReport = Date.now()
  await initializeSettings()
  await initializeActions()
  await loadSavedMyNodes()

  // Remove any handlers left from a previous start, then register fresh ones
  unsubs.forEach((u) => u())
  unsubs = []
  const listen = (ev: any, cb: (d: any) => void) => unsubs.push(DeskThing.on(ev, cb as any) as unknown as () => void)
  listen('hello', () => sendAll())
  listen('getTiles', (data: any) => getTiles(data))
  listen('toggleMyNode', (data: any) => toggleMyNode(data))
  listen('refreshMyNodes', () => loadMyNodes())
  listen('getChannels', () => loadChannels())
  listen('findNodes', (data: any) => findNodes(data))
  listen('setMention', (data: any) => setMention(data))
  listen('testAlert', () => raiseAlert('keyword', 'test:' + Date.now(), 'Test alert', 'Alerts are working. Tap to dismiss.'))
  listen('setFilter', (data: any) => {
    const g = data && data.payload && data.payload.groups
    clientGroups = Array.isArray(g) ? g.map((x: any) => String(x)).filter((x: string) => FILTER_GROUPS.indexOf(x) >= 0) : null
    console.log(`${TAG} Feed filter: ${clientGroups ? clientGroups.join(', ') || '(none)' : 'default'}`)
  })
  listen('getMessages', (data: any) => getMessages(data))
  listen(DESKTHING_EVENTS.SETTINGS, (data: any) => apply(data && data.payload))
  listen(DESKTHING_EVENTS.ACTION, (data: any) => {
    const id = (data && data.payload && data.payload.id) || (data && data.id)
    if (id) send('cmd', { cmd: id })
  })

  budgetTimer = setInterval(() => {
    routeBudget = MAX_ROUTES_PER_SEC
  }, 1000)
  statusTimer = setInterval(sendStatus, 5000)
  nodeTimer = setInterval(loadNodes, 10 * 60 * 1000)
  myNodesTimer = setInterval(loadMyNodes, 2 * 60 * 1000)
  channelTimer = setInterval(loadChannels, 60 * 1000)
  alertTimer = setInterval(checkSilent, 60 * 1000)
  wsWatchdog = setInterval(checkWS, 30000)

  await applyNow()
}

const stop = async () => {
  console.log(`${TAG} Stopping`)
  running = false
  unsubs.forEach((u) => u())
  unsubs = []
  dropWS()
  ;[wsTimer, demoTimer, settingsDebounce].forEach((t) => t && clearTimeout(t))
  ;[wsWatchdog, nodeTimer, myNodesTimer, statusTimer, budgetTimer, channelTimer, alertTimer].forEach((t) => t && clearInterval(t))
  wsTimer = demoTimer = settingsDebounce = null
  wsWatchdog = nodeTimer = myNodesTimer = statusTimer = budgetTimer = channelTimer = alertTimer = null
}

DeskThing.on(DESKTHING_EVENTS.START, start)
DeskThing.on(DESKTHING_EVENTS.STOP, stop)
