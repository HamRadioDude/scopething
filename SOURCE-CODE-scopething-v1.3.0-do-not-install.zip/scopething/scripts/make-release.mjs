// Turns a `npm run build` output into the files a GitHub release needs so
// DeskThing can install and auto-update ScopeThing from the HamThing repo.
//
//   node scripts/make-release.mjs
//
// Output (release/<appId>-v<version>/):
//   <appId>-v<version>.zip   the app
//   <appId>.json             app info DeskThing reads (version, hash, download link)
//   latest.json              repo index listing every app in this repo ("multi" release)
//
// Attach all three to a GitHub release tagged <appId>-v<version>.
import fs from 'node:fs'
import path from 'node:path'

const REPO = 'https://github.com/HamRadioDude/HamThing'
// Every app id published from this repo. Add others (e.g. 'flex-thing') once they have releases too.
const REPO_APP_IDS = ['scopething']

const dist = path.resolve('dist')
const appJson = JSON.parse(fs.readFileSync(path.join(dist, 'latest.json'), 'utf8'))
const id = appJson.appManifest.id
const version = appJson.appManifest.version
const tag = `${id}-v${version}`
const zipName = `${id}-v${version}.zip`
const zipPath = path.join(dist, zipName)
if (!fs.existsSync(zipPath)) throw new Error(`Missing ${zipPath}. Run npm run build first.`)

const downloadUrl = `${REPO}/releases/download/${tag}/${zipName}`
appJson.repository = REPO
appJson.updateUrl = downloadUrl
appJson.appManifest.repository = REPO
appJson.appManifest.updateUrl = REPO
appJson.size = fs.statSync(zipPath).size

const multi = {
  meta_version: '0.11.8',
  meta_type: 'multi',
  repository: REPO,
  fileIds: REPO_APP_IDS,
  repositories: [REPO]
}

const out = path.resolve('release', tag)
fs.mkdirSync(out, { recursive: true })
fs.copyFileSync(zipPath, path.join(out, zipName))
fs.writeFileSync(path.join(out, `${id}.json`), JSON.stringify(appJson, null, 2))
fs.writeFileSync(path.join(out, 'latest.json'), JSON.stringify(multi, null, 2))
console.log(`Release files for ${tag} in ${out}:`)
for (const f of fs.readdirSync(out)) console.log('  ' + f)
console.log(`\nGitHub release tag: ${tag}\nDownload URL: ${downloadUrl}`)
