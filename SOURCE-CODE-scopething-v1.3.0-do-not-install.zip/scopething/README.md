# ScopeThing

A live MeshCore traffic map for the Spotify Car Thing, running on DeskThing.
ScopeThing reads a CoreScope server and draws a streak along each packet's path
as it is heard: adverts, channel messages, DMs, traces.

Part of the HamThing family by DudeTested.

If ScopeThing makes your shack better, you can [buy me a coffee](https://buymeacoffee.com/hamradiodude). There's also a QR code on the Car Thing's STATUS screen.

## Screens

| Screen | What it shows |
|---|---|
| **MAP** | Live streaks on a dark map and the last 5 packets. Zoom, recenter and pause buttons sit along the bottom right, clear of the knob. Tap a node to see it and star it. |
| **FEED** | Scrolling packet list with filter chips along the bottom: ADVERT, CHANNEL, DM, TRACE, PATH, CONTROL (acks, requests, responses). The filter also applies to the map streaks. |
| **CHANNELS** | Channel list (latest activity first) and the selected channel's messages. Each message shows which observers heard it, plus hops and SNR. New messages arrive live, and a badge on the tab counts unread ones. |
| **MY NODES** | Your starred nodes (checkerboard colors so each one stands apart): active/degraded/silent, last heard, average SNR, packets today, observers. |
| **STATUS** | Connection, packets per minute, server, area, radius, and the observer list (online status, IATA region, packets per hour). |

Nothing you can tap sits in the top-right corner, because the Car Thing's knob covers it.

### Ambient mode
A full-screen map with just the streaks, a big clock, your area and the latest packet. Turn it on with the
corners button on the map (or the **Ambient Mode** action). It also starts on its own after a few idle
minutes (setting). After sunset at your area it dims to about 40% (setting: auto / always / never).
Tap anywhere to exit.

Tip: turn off DeskThing's own screensaver on the Car Thing, or it will cover ambient mode.

### Alerts
A banner and a colored flash around the screen, plus a history behind the bell in the header:
- **My Nodes back on the air:** heard again after being quiet (default 60 min).
- **My Nodes gone silent:** not heard for a while (default 6 h, once per silence).
- **Channel keywords:** any channel message containing your words or callsign.
- **New nodes:** a never-seen node adverts inside your area (off by default).
- **@mentions:** someone @mentions a node you watch in a channel, either as `@[Ridge-RPT]` (MeshCore app style) or `@Ridge-RPT`. Tapping it opens that channel.

### Find node and @mentions
On **MY NODES**, tap **Find node / @ mentions** to get an on-screen keyboard. Type part of a name, then for each match:
**★** adds it to My Nodes, **@** watches it for mentions, and **Map** shows it. Watched names appear as chips at the top; tap × to stop watching.
You can also watch mentions from a node's card on the map, or list names in settings. My Nodes are watched automatically (setting).

Tap a banner or a history entry to jump to that node on the map, or to the channel.

## Install

**Easiest (gets updates automatically):**
1. In DeskThing, go to **Downloads > Apps** and choose **Add Repo**.
2. Paste `https://github.com/HamRadioDude/HamThing`.
3. Install ScopeThing from the list. When a new version is released, DeskThing offers the update.

**Manual:** go to **Apps > Add App > Upload** and choose `scopething-v1.3.0.zip`.
To try it without a CoreScope server, turn on **Demo mode** in its settings.

## Settings (DeskThing app > ScopeThing)

| Setting | What it does |
|---|---|
| CoreScope server | Any CoreScope instance, e.g. `https://corescope.chicagolandmesh.org` |
| Area to watch | City, zip, or `lat, lon`. City names are looked up once with OpenStreetMap Nominatim. |
| Radius (miles) | Only traffic that touches this circle is shown. |
| Watch one repeater | Optional. A repeater name or key prefix. Shows only packets through that repeater and centers the map on it. |
| My Nodes | Comma-separated names or key prefixes. You can also star nodes right on the Car Thing. |
| Map style | Dark, light, or no map (grid only, least data). |
| CARTO map key | Optional. Blank = OpenStreetMap tiles (darkened for the dark style). CARTO's own tiles need a free key since 2026: get one at carto.com/basemaps/apikey. |
| Show ACK / request traffic | Off by default to keep the map readable. |
| Demo mode | Made-up traffic around your area. No server needed. |
| Alert: My Nodes | Back-on-air and gone-silent alerts for your starred nodes. |
| Alert: back on air after quiet (min) | How long a My Node must be quiet before hearing it again alerts you. |
| Alert: gone silent after (hours) | How long without hearing a My Node before it alerts you. |
| Alert: channel keywords | Comma-separated words or callsigns to watch for in channel messages. |
| Alert: @mentions of these nodes | Comma-separated node names to watch for @mentions in channels. |
| Alert: @mentions of My Nodes | Also watch every My Node for @mentions (on by default). |
| Alert: new nodes in my area | Alert when a node never seen before adverts inside your area. |
| Ambient mode after idle (minutes) | 0 = only by button. |
| Dim at night | Auto (after sunset at your area), always, or never. |

## Buttons and knob

- The **knob** zooms the map and scrolls the lists.
- To use the Car Thing's **preset buttons**, open **DeskThing > Mappings** and assign
  the ScopeThing actions: Map Screen, Feed Screen, Channels Screen, My Nodes Screen, Status Screen,
  Next Screen, Zoom In, Zoom Out, Recenter, Pause / Resume, Ambient Mode.
- Drag on the map to pan. Tap a node to open its card.

## How it works

- **Server (your PC):** connects to CoreScope's `/ws` WebSocket and its public
  `/api/nodes`, `/api/observers`, `/api/channels`, `/api/channels/{hash}/messages`
  and `/api/nodes/{key}/health` endpoints. It resolves
  each packet's hops to coordinates, using CoreScope's `resolved_path` first and
  nearest-match key prefixes as a fallback. It keeps only what is in your area, and
  sends small route messages to the Car Thing (at most 12 per second).
- **Car Thing:** draws everything on two canvases (base map plus animated streaks).
  It can't reach the internet, so the server fetches the map tiles and passes them
  along.
- Hops longer than 250 miles are treated as bad matches and skipped, so internet
  bridges don't draw streaks across the country.

## Troubleshooting

- **STATUS says OFFLINE or Connecting:** check the server address in a web browser on
  the same PC. It must be a CoreScope server, not the Chicagoland Mesh docs page.
- **Map is blank but streaks show:** the PC can't reach the tile server. Set Map style
  to "No map".
- **Area shows "(not found)":** use `lat, lon` instead of a city name.
- **Repeater not found:** use its exact name as shown in CoreScope, or 4+ characters
  of its public key.

## Build from source

```bash
npm install
npm run build        # -> dist/scopething-v1.1.0.zip
```

## Credits

- Live data: [CoreScope](https://github.com/Kpa-clawbot/CoreScope) (GPL-3.0). ScopeThing
  only reads its public API and contains none of its code.
- Map tiles: © OpenStreetMap contributors (tile.openstreetmap.org by default), © CARTO when a CARTO key is set.
- Geocoding: OpenStreetMap Nominatim.

## License

MIT, see LICENSE.
